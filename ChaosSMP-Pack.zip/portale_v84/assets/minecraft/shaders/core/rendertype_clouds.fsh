#version 330

// Vanilla core/rendertype_clouds.fsh (26.1/26.2) + ChaosSMP Portal-Ankunft: keine Wolken, solange die Ankunfts-Szene
// noch Ungebautes fuellt (sonst laegen Wolken unter dem Luftschiff ueber der Szene)

#moj_import <minecraft:globals.glsl>

// ChaosSMP Portal-Ankunft (docs/PORTALE.md "Ultra 3"): der Server setzt das Ziel eines Portal-Teleports auf X/Z mit
// fract(16 * Koordinate) = 17/32 (PortalAnkunft.merken, hoechstens 1/32 Block Versatz). Steht die Kamera so, ist der
// Ladebildschirm durchsichtig: man sieht die neue Welt und die Ankunfts-Szene statt des Panoramas (wie bei Hugo).
// Die Nachkommastelle steckt exakt in CameraOffset (= floor(Kamera) - Kamera, globals).
bool chaosAnkunft() {
    vec2 f = fract(fract(-CameraOffset.xz) * 16.0);
    return all(lessThan(abs(f - 0.53125), vec2(0.006)));
}

// ChaosSMP Dungeon-Ankunft (Schwarzblende.ladebildSchwarz, docs/DUNGEON.md §7.1): Ziel X/Z mit fract(16 * Koordinate) = 9/32.
// Steht die Kamera so, ist das Ladebild schwarz statt Himmelsverlauf — die Schwarzblende davor und danach geht ohne Himmel durch.
bool chaosLadeSchwarz() {
    vec2 f = fract(fract(-CameraOffset.xz) * 16.0);
    return all(lessThan(abs(f - 0.28125), vec2(0.006)));
}


#moj_import <minecraft:fog.glsl>


in float vertexDistance;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    if (chaosAnkunft())
        discard;
    vec4 color = vertexColor;
    color.a *= 1.0f - linear_fog_value(vertexDistance, 0, FogCloudsEnd);
    fragColor = color;
}
