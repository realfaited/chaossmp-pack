#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

// ChaosSMP Voxel-Portale (21.10.2026, docs/PORTALE.md): Vanilla-Outline + Datenkanal.
// Ein leuchtendes Marker-Item (Sprite chaossmp:portal/marke_<n>, Stempel R=201 A=255, G=0x50|Slot, B=0x8C|Ecke)
// wird nicht als Umriss gezeichnet, sondern auf die Datenzeile <Slot> unten links im Outline-Puffer gelegt.
// Dort stehen Steuerwort (Glow-Farbe), Lage des Markers relativ zur Kamera, ModelView 3x3 und Projektion.

uniform sampler2D Sampler0;

in vec3 Position;
in vec4 Color;
in vec2 UV0;

out vec4 vertexColor;
out vec2 texCoord0;

flat out int chaosSlot;
flat out int chaosWord;
flat out vec3 chaosPos;
flat out mat3 chaosView;
flat out vec4 chaosProj;

const int CHAOS_SPALTEN = 17;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexColor = Color;
    texCoord0 = UV0;

    chaosSlot = -1;
    chaosWord = 0;
    chaosPos = vec3(0.0);
    chaosView = mat3(1.0);
    chaosProj = vec4(0.0);

    ivec2 groesse = textureSize(Sampler0, 0);
    if (groesse.x < 256 || groesse.y < 256)
        return;
    ivec2 at = clamp(ivec2(floor(UV0 * vec2(groesse))), ivec2(0), groesse - 1);
    ivec4 t = ivec4(round(texelFetch(Sampler0, at, 0) * 255.0));
    if (t.r != 201 || t.a != 255 || (t.g & 0xF8) != 0x50 || (t.b & 0xFC) != 0x8C)
        return;
    int slot = t.g & 7;
    if (slot > 3)
        return;
    vec2 ecke = vec2(float(t.b & 1), float((t.b >> 1) & 1));
    vec2 px = vec2(ecke.x * float(CHAOS_SPALTEN), float(slot) + ecke.y);
    gl_Position = vec4(px / ScreenSize * 2.0 - 1.0, 0.9, 1.0);
    ivec3 c = ivec3(round(Color.rgb * 255.0));
    chaosSlot = slot;
    chaosWord = (c.r << 16) | (c.g << 8) | c.b;
    chaosPos = Position;
    chaosView = mat3(ModelViewMat);
    chaosProj = vec4(ProjMat[0][0], ProjMat[1][1], ProjMat[2][2], ProjMat[3][2]);
}
