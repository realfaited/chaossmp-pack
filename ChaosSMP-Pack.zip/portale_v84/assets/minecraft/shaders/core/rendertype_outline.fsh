#version 330

#moj_import <minecraft:dynamictransforms.glsl>

// ChaosSMP Voxel-Portale: Marker schreiben exakte 32-Bit-Werte (RGBA, ohne Blending), normale Umrisse
// sparen den Datenbereich (24x8 Pixel unten links) aus. Siehe rendertype_outline.vsh.

uniform sampler2D Sampler0;

in vec4 vertexColor;
in vec2 texCoord0;

flat in int chaosSlot;
flat in int chaosWord;
flat in vec3 chaosPos;
flat in mat3 chaosView;
flat in vec4 chaosProj;

out vec4 fragColor;

vec4 chaosBits(uint u) {
    return vec4(float((u >> 24u) & 255u), float((u >> 16u) & 255u), float((u >> 8u) & 255u), float(u & 255u)) / 255.0;
}

void main() {
    if (chaosSlot >= 0) {
        // 26.10.2026 (Lunar-Fall): nur die eigene Zeile und Spalten 0-16 schreiben — passt ScreenSize nicht zur Groesse
        // des Outline-Puffers (Client mit eigener Aufloesung), landet das Quad sonst verschoben/gestreckt auf fremden Zeilen
        int spalte = int(gl_FragCoord.x);
        if (int(gl_FragCoord.y) != chaosSlot || spalte > 16)
            discard;
        if (spalte == 0) {
            fragColor = chaosBits((uint(chaosWord) << 8u) | 0xA5u);
            return;
        }
        float v = 0.0;
        if (spalte <= 3)
            v = chaosPos[spalte - 1];
        else if (spalte <= 12)
            v = chaosView[(spalte - 4) / 3][(spalte - 4) % 3];
        else
            v = chaosProj[min(spalte - 13, 3)];
        fragColor = chaosBits(floatBitsToUint(v));
        return;
    }
    if (gl_FragCoord.x < 24.0 && gl_FragCoord.y < 8.0)
        discard;
    vec4 color = texture(Sampler0, texCoord0);
    if (color.a == 0.0) {
        discard;
    }
    fragColor = vec4(ColorModulator.rgb * vertexColor.rgb, ColorModulator.a);
}
