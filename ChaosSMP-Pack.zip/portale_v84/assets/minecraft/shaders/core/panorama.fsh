#version 330

// Vanilla core/panorama.fsh (26.1/26.2) + ChaosSMP Portal-Ankunft: Panorama des Ladebildschirms weglassen.

layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    vec3 CameraOffset;
    vec2 ScreenSize;
    float GlintAlpha;
    float GameTime;
    int MenuBlurRadius;
    int UseRgss;
};

// ChaosSMP Portal-Ankunft (docs/PORTALE.md "Ultra 3"): der Server setzt das Ziel eines Portal-Teleports auf X/Z mit
// fract(16 * Koordinate) = 17/32 (PortalAnkunft.merken, hoechstens 1/32 Block Versatz). Steht die Kamera so, ist der
// Ladebildschirm durchsichtig: man sieht die neue Welt und die Ankunfts-Szene statt des Panoramas (wie bei Hugo).
// Die Nachkommastelle steckt exakt in CameraOffset (= floor(Kamera) - Kamera, globals).
bool chaosAnkunft() {
    vec2 f = fract(fract(-CameraOffset.xz) * 16.0);
    return all(lessThan(abs(f - 0.53125), vec2(0.006)));
}


uniform samplerCube Sampler0;

in vec3 texCoord0;

out vec4 fragColor;

void main() {
    // Portal-Ankunft (Merk-Koordinate) und die ersten Bilder einer neuen Welt (Zeit noch 0: das vom Client erzwungene Bild
    // und das erste Weltbild, Kamera noch auf der alten Welt): kein Panorama — box_blur.fsh zeigt dort die Ankunfts-Szene
    // bzw. einen gedaempften Ersatz
    if (chaosAnkunft() || GameTime < 5.0e-5)
        discard;
    fragColor = texture(Sampler0, texCoord0);
}
