#version 330

// Vanilla core/screenquad.vsh (26.1/26.2) + ChaosSMP Voxel-Portale (Ultra-Plan 21.10.2026): traegt das Eingangsbild an
// Pixel (0,0) das Merkzeichen der Portal-Kette (RGBA 0x5A, 0xC3, 0x3C, 0 — nur im Outline-Puffer, wenn ausschliesslich
// Portal-Marker leuchten), wird das Dreieck entartet: das Einblenden eines leeren Outline-Puffers entfaellt.
// Alle anderen Nutzer (Post-Paesse, Bildschirm-Blit) sehen das Zeichen nie und laufen unveraendert.

uniform sampler2D InSampler;

out vec2 texCoord;

void main() {
    vec2 uv = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2);
    vec4 pos = vec4(uv * vec2(2, 2) + vec2(-1, -1), 0, 1);
    ivec4 m = ivec4(round(texelFetch(InSampler, ivec2(0), 0) * 255.0));
    if (m == ivec4(90, 195, 60, 0))
        pos = vec4(-3.0, -3.0, 0.0, 1.0);

    gl_Position = pos;
    texCoord = uv;
}
