#version 330

// Vanilla core/particle.fsh (26.1/26.2, auch Regen/Schnee) + ChaosSMP Portal-Ankunft: keine Partikel/Regen ueber der
// Ankunfts-Szene, solange der Ladebildschirm offen ist

#moj_import <minecraft:globals.glsl>

// ChaosSMP Portal-Ankunft (docs/PORTALE.md "Ultra 3"): der Server setzt das Ziel eines Portal-Teleports auf X/Z mit
// fract(16 * Koordinate) = 17/32 (PortalAnkunft.merken, hoechstens 1/32 Block Versatz). Steht die Kamera so, ist der
// Ladebildschirm durchsichtig: man sieht die neue Welt und die Ankunfts-Szene statt des Panoramas (wie bei Hugo).
// Die Nachkommastelle steckt exakt in CameraOffset (= floor(Kamera) - Kamera, globals).
bool chaosAnkunft() {
    vec2 f = fract(fract(-CameraOffset.xz) * 16.0);
    return all(lessThan(abs(f - 0.53125), vec2(0.006)));
}


#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    if (chaosAnkunft())
        discard;
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
