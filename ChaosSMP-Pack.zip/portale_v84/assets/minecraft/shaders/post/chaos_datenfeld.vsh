#version 330

// ChaosSMP Voxel-Portale, Ultra-Plan 21.10.2026: Dreieck nur ueber dem Marker-Datenbereich (24x8 unten links).
// Dazu: gibt es echte Umrisse (chaos_kacheln)? Nein -> chaos_scrub setzt das Merkpixel fuer core/screenquad.vsh.

uniform sampler2D KachelnSampler;

out vec2 texCoord;
flat out int chaosLeer;

void main() {
    vec2 bild = vec2(textureSize(KachelnSampler, 0));
    ivec2 n = ivec2(ceil(bild / 32.0));
    int belegt = 0;
    for (int y = 0; y < n.y && belegt == 0; y++)
        for (int x = 0; x < n.x; x++)
            if (texelFetch(KachelnSampler, ivec2(x, y), 0).r > 0.5) {
                belegt = 1;
                break;
            }
    chaosLeer = 1 - belegt;
    vec2 hi = vec2(24.0, 8.0) / bild * 2.0 - 1.0;
    vec2 lo = vec2(-1.0);
    vec2 ecke = gl_VertexID == 0 ? lo : (gl_VertexID == 1 ? vec2(2.0 * hi.x - lo.x, lo.y) : vec2(lo.x, 2.0 * hi.y - lo.y));
    gl_Position = vec4(ecke, 0.0, 1.0);
    texCoord = ecke * 0.5 + 0.5;
}
