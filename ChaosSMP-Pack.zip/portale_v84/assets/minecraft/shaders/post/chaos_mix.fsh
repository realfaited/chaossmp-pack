#version 330

// ChaosSMP Voxel-Portale, Ultra-Plan 21.10.2026: Portalpixel in voller Aufloesung ins Hauptbild.
// Liest nur chaos_klein (halbe Aufloesung aus chaos_portal): je Block Farbe + Slot + Deckungsmaske der vier Bildpunkte.
// Gedeckt = Bit des eigenen Bildpunkts im eigenen Block; Farbe bilinear aus den bis zu vier Nachbar-Bloecken desselben
// Slots. Sonst discard. (Bit 17-20 des Steuerworts ist seit 21.10.2026 abends der Drin-Code, keine Deckkraft mehr.)

uniform sampler2D KleinSampler;

in vec2 texCoord;

flat in vec4 chaosRect;
flat in ivec4 chaosKopf[4];
flat in vec4 chaosLage[4];
flat in vec3 chaosInvX;
flat in vec3 chaosInvY;
flat in vec3 chaosInvZ;
flat in vec4 chaosProj;
flat in int chaosStufe;

out vec4 fragColor;

void main() {
    vec2 ndc = texCoord * 2.0 - 1.0;
    if (any(lessThan(ndc, chaosRect.xy)) || any(greaterThan(ndc, chaosRect.zw)))
        discard;
    ivec2 px = ivec2(gl_FragCoord.xy);
    // Stufe 1: Block 2x2, Stufe 2: Block 4x4 (Deckungsbit je 2x2-Viertel)
    ivec2 block = px >> chaosStufe;
    ivec2 viertel = (px >> (chaosStufe - 1)) & 1;
    int a0 = int(texelFetch(KleinSampler, block, 0).a * 255.0 + 0.5);
    int kennung = a0 & 7;
    if (kennung == 0 || ((a0 >> 3) >> (viertel.x | (viertel.y << 1)) & 1) == 0)
        discard;
    // Steuerwort des Slots ohne dynamischen Index in die flachen Varyings (llvmpipe: langsam)
    int wort = kennung == 1 ? chaosKopf[0].x : (kennung == 2 ? chaosKopf[1].x : (kennung == 3 ? chaosKopf[2].x : chaosKopf[3].x));
    if (wort < 0)
        discard;
    // Ankunfts-Komposit (Form 5) blendet aus: Bit 17-20 = Deckkraft 0..15, Raster-Ausduennung (Bayer 4x4)
    int form = kennung == 1 ? chaosKopf[0].y : (kennung == 2 ? chaosKopf[1].y : (kennung == 3 ? chaosKopf[2].y : chaosKopf[3].y));
    if (form == 5) {
        int deck = (wort >> 17) & 15;
        const int BAYER[16] = int[](0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5);
        if (deck < 15 && BAYER[(px.x & 3) + (px.y & 3) * 4] >= deck)
            discard;
    }
    ivec2 grenze = textureSize(KleinSampler, 0) / (1 << chaosStufe) - 1;
    vec2 u = (vec2(px) + 0.5) / float(1 << chaosStufe) - 0.5;
    ivec2 i0 = ivec2(floor(u));
    vec2 f = u - vec2(i0);
    vec3 summe = vec3(0.0);
    float gewicht = 0.0;
    for (int k = 0; k < 4; k++) {
        ivec2 o = ivec2(k & 1, k >> 1);
        ivec2 q = clamp(i0 + o, ivec2(0), grenze);
        // eigener Block schon gelesen
        vec4 c = q == block ? texelFetch(KleinSampler, block, 0) : texelFetch(KleinSampler, q, 0);
        int ak = int(c.a * 255.0 + 0.5);
        // anderer Slot oder Schachbrett-Luecke (Bit 7, chaos_portal) zaehlt nicht
        if ((ak & 7) != kennung || ak >= 128)
            continue;
        float g = (o.x == 1 ? f.x : 1.0 - f.x) * (o.y == 1 ? f.y : 1.0 - f.y) + 1e-4;
        summe += c.rgb * g;
        gewicht += g;
    }
    if (gewicht <= 0.0) {
        // Luecke ohne Nachbarn im eigenen Viertel: die vier Kanten-Nachbarn
        for (int k = 0; k < 4; k++) {
            ivec2 q = clamp(block + ivec2(k == 0 ? 1 : (k == 1 ? -1 : 0), k == 2 ? 1 : (k == 3 ? -1 : 0)), ivec2(0), grenze);
            vec4 c = texelFetch(KleinSampler, q, 0);
            int ak = int(c.a * 255.0 + 0.5);
            if ((ak & 7) != kennung || ak >= 128)
                continue;
            summe += c.rgb;
            gewicht += 1.0;
        }
        if (gewicht <= 0.0)
            discard;
    }
    fragColor = vec4(summe / max(gewicht, 1e-4), 1.0);
}
