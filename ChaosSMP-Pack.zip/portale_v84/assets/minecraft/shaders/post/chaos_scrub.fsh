#version 330

// ChaosSMP Voxel-Portale: Datenbereich im Outline-Puffer loeschen (chaos_datenfeld.vsh zeichnet nur 24x8 unten
// links), damit Sobel/Blur und das Vanilla-Einblenden nur echte Umrisse sehen. Leuchten nur Portal-Marker (keine
// echten Umrisse), bekommt Pixel (0,0) das Merkzeichen RGBA (0x5A, 0xC3, 0x3C, 0): unser core/screenquad.vsh laesst
// dann das Vanilla-Einblenden des (leeren) Outline-Puffers ganz weg. Alpha 0 = unsichtbar, falls doch eingeblendet.

uniform sampler2D KachelnSampler;

in vec2 texCoord;
flat in int chaosLeer;

out vec4 fragColor;

void main() {
    ivec2 px = ivec2(gl_FragCoord.xy);
    fragColor = chaosLeer == 1 && px == ivec2(0) ? vec4(90.0, 195.0, 60.0, 0.0) / 255.0 : vec4(0.0);
}
