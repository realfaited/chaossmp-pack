#version 330

// ChaosSMP Voxel-Portale, Ultra-Plan 21.10.2026: Kachel-Suche nach echten Umrissen. Ein Pixel je 32x32-Kachel des
// Outline-Puffers, gezeichnet ins linke untere Eck von chaos_kacheln (das Ziel hat Bildschirmgroesse).

uniform sampler2D InSampler;

out vec2 texCoord;

void main() {
    vec2 bild = vec2(textureSize(InSampler, 0));
    vec2 kacheln = ceil(bild / 32.0);
    vec2 hi = kacheln / bild * 2.0 - 1.0;
    vec2 lo = vec2(-1.0);
    vec2 ecke = gl_VertexID == 0 ? lo : (gl_VertexID == 1 ? vec2(2.0 * hi.x - lo.x, lo.y) : vec2(lo.x, 2.0 * hi.y - lo.y));
    gl_Position = vec4(ecke, 0.0, 1.0);
    texCoord = ecke * 0.5 + 0.5;
}
