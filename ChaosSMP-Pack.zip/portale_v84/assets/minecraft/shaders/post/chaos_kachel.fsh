#version 330

// ChaosSMP Voxel-Portale, Ultra-Plan 21.10.2026: belegt die Kachel (32x32 Bildpunkte) einen echten Umriss?
// Abtastung jedes 4. Bildpunkts (Silhouetten sind gefuellt: alles ab 4x4 Bildpunkten wird gefunden; kleinere
// Silhouetten bleiben ohne Sobel/Blur, sind aber auch nur ein paar Pixel gross). Der
// Marker-Datenbereich (24x8 unten links) zaehlt nicht. Ausgabe R = 1 belegt, sonst 0.

uniform sampler2D InSampler;

out vec4 fragColor;

void main() {
    ivec2 kachel = ivec2(gl_FragCoord.xy);
    ivec2 bild = textureSize(InSampler, 0);
    ivec2 basis = kachel * 32;
    float belegt = 0.0;
    for (int y = 0; y < 8 && belegt < 0.5; y++) {
        int py = basis.y + y * 4 + 1;
        if (py >= bild.y)
            break;
        for (int x = 0; x < 8; x++) {
            ivec2 p = ivec2(basis.x + x * 4 + 1, py);
            if (p.x >= bild.x)
                break;
            if (p.x < 24 && p.y < 8)
                continue;
            if (texelFetch(InSampler, p, 0).a > 0.0) {
                belegt = 1.0;
                break;
            }
        }
    }
    fragColor = vec4(belegt, 0.0, 0.0, 1.0);
}
