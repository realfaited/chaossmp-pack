#version 330
#define CHAOS_RAND 6.0

// ChaosSMP Voxel-Portale, Ultra-Plan 21.10.2026: Vertex-Shader der Vanilla-Umriss-Paesse (Sobel, Blur, Blit).
// Zeichnet nur das Rechteck um die belegten Kacheln (chaos_kachel) plus CHAOS_RAND Bildpunkte; keine echten Umrisse
// (nur Portal-Marker leuchten) = entartetes Dreieck = die Paesse kosten nichts. Jeder Pass hat 3 Bildpunkte weniger
// Rand als der vorige (liest hoechstens 2 daneben) -> nie ungeschriebene Bildpunkte lesen.

#ifndef CHAOS_RAND
#define CHAOS_RAND 6.0
#endif

uniform sampler2D KachelnSampler;

out vec2 texCoord;

void main() {
    vec2 bild = vec2(textureSize(KachelnSampler, 0));
    ivec2 n = ivec2(ceil(bild / 32.0));
    ivec2 lo = n;
    ivec2 hi = ivec2(-1);
    for (int y = 0; y < n.y; y++)
        for (int x = 0; x < n.x; x++)
            if (texelFetch(KachelnSampler, ivec2(x, y), 0).r > 0.5) {
                lo = min(lo, ivec2(x, y));
                hi = max(hi, ivec2(x, y));
            }
    if (hi.x < 0) {
        gl_Position = vec4(-3.0, -3.0, 0.0, 1.0);
        texCoord = vec2(0.0);
        return;
    }
    vec2 a = max(vec2(lo * 32) - CHAOS_RAND, vec2(0.0)) / bild * 2.0 - 1.0;
    vec2 b = min(vec2((hi + 1) * 32) + CHAOS_RAND, bild) / bild * 2.0 - 1.0;
    vec2 ecke = gl_VertexID == 0 ? a : (gl_VertexID == 1 ? vec2(2.0 * b.x - a.x, a.y) : vec2(a.x, 2.0 * b.y - a.y));
    gl_Position = vec4(ecke, 0.0, 1.0);
    texCoord = ecke * 0.5 + 0.5;
}
