#version 330

// Vanilla post/box_blur.fsh (26.1/26.2, nur post_effect/blur = Menue-Unschaerfe) + ChaosSMP Portal-Ankunft: keine
// Unschaerfe hinter dem Ladebildschirm, das Bild geht unveraendert durch.

#moj_import <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform BlurConfig {
    vec2 BlurDir;
    float Radius;
};

// ChaosSMP Portal-Ankunft (docs/PORTALE.md "Ultra 3"): der Server setzt das Ziel eines Portal-Teleports auf X/Z mit
// fract(16 * Koordinate) = 17/32 (PortalAnkunft.merken, hoechstens 1/32 Block Versatz). Steht die Kamera so, ist der
// Ladebildschirm durchsichtig: man sieht die neue Welt und die Ankunfts-Szene statt des Panoramas (wie bei Hugo).
// Die Nachkommastelle steckt exakt in CameraOffset (= floor(Kamera) - Kamera, globals).
bool chaosAnkunft() {
    vec2 f = fract(fract(-CameraOffset.xz) * 16.0);
    return all(lessThan(abs(f - 0.53125), vec2(0.006)));
}

// ChaosSMP Dungeon-Ankunft (Schwarzblende.ladebildSchwarz, docs/DUNGEON.md §7.1): Ziel X/Z mit fract(16 * Koordinate) = 9/32.
// Steht die Kamera so, ist das Ladebild schwarz statt Himmelsverlauf — die Schwarzblende davor und danach geht ohne Himmel durch.
bool chaosLadeSchwarz() {
    vec2 f = fract(fract(-CameraOffset.xz) * 16.0);
    return all(lessThan(abs(f - 0.28125), vec2(0.006)));
}


in vec2 texCoord;

out vec4 fragColor;

void main() {
    bool neueWelt = GameTime < 5.0e-5;
    if (chaosAnkunft() || neueWelt) {
        // Dungeon-Ankunft (merk.glsl chaosLadeSchwarz): auch das erzwungene erste Bild schwarz statt Himmelsverlauf
        if (neueWelt && chaosLadeSchwarz()) {
            fragColor = vec4(0.0, 0.0, 0.0, 1.0);
            return;
        }
        vec4 c = texelFetch(InSampler, ivec2(gl_FragCoord.xy), 0);
        if (neueWelt && !chaosAnkunft()) {
            // Vom Client erzwungenes erstes Bild nach dem Respawn-Paket: es wurde keine Welt gezeichnet (Hauptbild noch auf
            // dem Loeschwert 0) -> ruhiger, gedaempfter Himmelsverlauf statt Schwarz bzw. hellem Panorama. Sobald eine Welt
            // gezeichnet ist (erstes Weltbild, Kamera noch alt; bei Portal-Reisen mit Ankunfts-Szene), bleibt das Bild.
            if (texelFetch(InSampler, ivec2(InSize * 0.5), 0) == vec4(0.0) && texelFetch(InSampler, ivec2(InSize * vec2(0.25, 0.75)), 0) == vec4(0.0))
                c = vec4(mix(vec3(0.27, 0.30, 0.36), vec3(0.20, 0.25, 0.36), texCoord.y), 1.0);
        }
        fragColor = c;
        return;
    }
    vec2 oneTexel = 1.0 / InSize;
    vec2 sampleStep = oneTexel * BlurDir;

    vec4 blurred = vec4(0.0);
    float actualRadius = Radius >= 0.5 ? round(Radius) : float(MenuBlurRadius);
    for (float a = -actualRadius + 0.5; a <= actualRadius; a += 2.0) {
        blurred += texture(InSampler, texCoord + sampleStep * a);
    }
    blurred += texture(InSampler, texCoord + sampleStep * actualRadius) / 2.0;
    fragColor = blurred / (actualRadius + 0.5);
}
