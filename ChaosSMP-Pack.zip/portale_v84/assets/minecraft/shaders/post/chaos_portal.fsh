#version 330

// ChaosSMP Voxel-Portale, Ultra-Plan 21.10.2026 (docs/PORTALE.md "Ultra-Plan"). Raymarcher nach Hugos Lumiere
// (_qiy, Freigabe des Owners 21.10.2026) auf unser Datenformat umgebaut.
//
// Laeuft in halber Aufloesung nur im Rechteck aus chaos_feld.vsh (CHAOS_HALB). Je Block: Flaechenwahl (chaos_wahl.glsl),
// dann DDA durch den Voxel-Schnappschuss der Zielwelt. chaos_mix schreibt daraus die Portalpixel in voller Aufloesung
// ins Hauptbild (ohne Tiefe zu lesen: die exakte Deckung je Bildpunkt steht schon in der Maske).
//
// Texturen (portale_voxel.py, Zeile 0 = oberste PNG-Zeile):
//   Voxels  768 x 768*S   Zelle (x,y,z): Texel (x + (y%8)*96, z + (y/8)*96 + s*768); R + B*256 = Palette, G = Himmel<<4|Block,
//                         A = 255 - Chebyshev-Abstand zur naechsten belegten Zelle (Leerraum-Sprung)
//   Palette 8 x 512*S     Zeile s*512+id: 0 oben|unten-Kachel, 1 nord|sued, 2 ost|west (je RG|BA = 16 Bit),
//                         3 Box (R minX<<4|minY, G minZ<<4|maxX-1, B maxY-1<<4|maxZ-1), 4 Toenung, 5 R Form
//                         (1 Box, 2 Kreuz, 3 Fluessigkeit) G Flags (1 Toenung oben, 2 Seiten, 4 unten, 16 leuchtet,
//                         32 Cutout, 64 durchscheinend), 6 Mittelfarbe oben (A Deckung), 7 Mittelfarbe Seite
//   Atlas   512 x 512     16er Kacheln, 32 je Zeile
//   Meta    16 x S        0-5 Anker 0/1 (24-Bit-Festkomma), 6 Dunst RGB (A Dichte/255 je Block), 7 Zenit, 8 Horizont,
//                         11 Tageslicht-Faktor der Aufnahme
//   Far     2048 x 384*S  Fernfeld, Breitenband +12..-52 Grad (A 0 = Himmel -> Verlauf Zenit/Horizont)

// #define CHAOS_HEAT   (Pack-Bau mit CHAOS_HEAT=1: Schritte/Dunst/Trefferart als Falschfarben)

#moj_import <minecraft:globals.glsl>

uniform sampler2D MainDepthSampler;
uniform sampler2D VoxelsSampler;
uniform sampler2D PaletteSampler;
uniform sampler2D AtlasSampler;
uniform sampler2D MetaSampler;
uniform sampler2D FarSampler;

// ChaosSMP Voxel-Portale, Ultra-Plan 21.10.2026: gemeinsame Flaechenwahl fuer chaos_portal (halbe Aufloesung) und
// chaos_mix (volle Aufloesung). Vom Pack-Bau an der Zeile "//#include chaos_wahl.glsl" eingesetzt.
// Eingaben kommen flach aus chaos_feld.vsh (einmal je Pass dekodierte Marker-Datenzeilen).

in vec2 texCoord;

flat in vec4 chaosRect;
flat in ivec4 chaosKopf[4];
flat in vec4 chaosLage[4];
flat in vec3 chaosInvX;
flat in vec3 chaosInvY;
flat in vec3 chaosInvZ;
flat in vec4 chaosProj;
flat in int chaosStufe;

// Tiefen-Toleranz je Form: Wand 0.02 (seit Ultra 3 liegt die Ebene VOR der Netherportal-Flaeche; 0.2 legte das Fenster
// ueber die Oberkante des Bodenblocks vor dem Portal = dunkles Band), Boden 0.08
const float TOL_WAND = 0.02;
const float TOL_BODEN = 0.08;

void basisVon(int form, vec3 pos, out vec3 n, out vec3 u, out vec3 w) {
    u = vec3(1.0, 0.0, 0.0);
    w = vec3(0.0, 0.0, 1.0);
    n = vec3(0.0, 1.0, 0.0);
    if (form == 2 || form == 6) {
        n = vec3(form == 2 ? 1.0 : -1.0, 0.0, 0.0);
        u = vec3(0.0, 0.0, 1.0);
        w = vec3(0.0, 1.0, 0.0);
    } else if (form == 3 || form == 7) {
        n = vec3(0.0, 0.0, form == 3 ? 1.0 : -1.0);
        u = vec3(1.0, 0.0, 0.0);
        w = vec3(0.0, 1.0, 0.0);
    } else if (form == 4) {
        vec2 h = pos.xz;
        n = dot(h, h) < 1e-8 ? vec3(0.0, 0.0, 1.0) : -normalize(vec3(h.x, 0.0, h.y));
        u = vec3(-n.z, 0.0, n.x);
        w = vec3(0.0, 1.0, 0.0);
    }
}

// Blickrichtung (Weltachsen, Sicht-Z = -1: t = Abstand entlang der Sichtachse)
vec3 chaosRichtung(vec2 ndc) {
    return mat3(chaosInvX, chaosInvY, chaosInvZ) * vec3(ndc.x / chaosProj.x, ndc.y / chaosProj.y, -1.0);
}

bool chaosUmgekehrt() {
    return abs(chaosProj.z) < 0.5;
}

// Himmel bzw. noch nichts gebaut (Tiefe = Loeschwert; 26.2 umgekehrtes Z)
bool chaosHimmel(float tiefe) {
    return chaosUmgekehrt() ? tiefe <= 0.0 : tiefe >= 1.0;
}

float chaosWeltT(float tiefe) {
    if (chaosHimmel(tiefe))
        return 1e30;
    float ndcZ = chaosUmgekehrt() ? tiefe : tiefe * 2.0 - 1.0;
    return chaosProj.w / (ndcZ + chaosProj.z);
}

// Schnitt des Strahls d mit der Flaeche von Slot slot; tHit = 0 bei Vollbild/Komposit/drin; false = nicht getroffen
bool chaosSlotTreffer(int slot, vec3 d, float weltT, bool himmel, out float tHit) {
    tHit = 0.0;
    int wort = chaosKopf[slot].x;
    if (wort < 0)
        return false;
    int form = chaosKopf[slot].y;
    if (form == 0 || chaosKopf[slot].z == 1)
        return true;
    if (form == 5)
        return himmel;
    vec3 pos = chaosLage[slot].xyz;
    vec3 n, u, w;
    basisVon(form, pos, n, u, w);
    float hb = float((wort >> 7) & 31) * 0.25;
    float hh = float((wort >> 12) & 31) * 0.25;
    bool rund = ((wort >> 6) & 1) != 0;
    float den = dot(d, n);
    if (abs(den) < 1e-7)
        return false;
    tHit = dot(pos, n) / den;
    if (tHit <= 0.0)
        return false;
    vec3 lokal = d * tHit - pos;
    vec2 a = abs(vec2(dot(lokal, u), dot(lokal, w)));
    if (a.x > hb || a.y > hh)
        return false;
    if (rund) {
        // Boden: Becken-Umriss = Rechteck ohne die vier Eckbloecke (Brunnen, aus der Welt gelesen: 7x7, Ecken Stein);
        // Scheibe (Wirbel): Kreis/Ellipse
        if (form == 1 ? (a.x > hb - 1.0 && a.y > hh - 1.0) : dot(a / max(vec2(hb, hh), 0.01), a / max(vec2(hb, hh), 0.01)) > 1.0)
            return false;
    }
    float tol = form == 1 ? TOL_BODEN : TOL_WAND;
    // Toleranz in Bloecken entlang der Normalen -> in t-Einheiten
    return !(weltT < tHit - tol / max(abs(den), 0.2 * length(d)));
}

// Naechster getroffener Slot fuer den Bildpunkt ndc mit Tiefe tiefe (-1 = keiner)
int chaosWahl(vec2 ndc, float tiefe, out float wahlT) {
    vec3 d = chaosRichtung(ndc);
    float weltT = chaosWeltT(tiefe);
    bool himmel = chaosHimmel(tiefe);
    int wahl = -1;
    wahlT = 1e30;
    for (int slot = 0; slot < 4; slot++) {
        float t;
        if (chaosSlotTreffer(slot, d, weltT, himmel, t) && t < wahlT) {
            wahl = slot;
            wahlT = t;
        }
    }
    return wahl;
}

bool chaosImRechteck(vec2 ndc) {
    return all(greaterThanEqual(ndc, chaosRect.xy)) && all(lessThanEqual(ndc, chaosRect.zw));
}


out vec4 fragColor;

const ivec3 GR = ivec3(96, 64, 96);
const vec3 GRF = vec3(96.0, 64.0, 96.0);
const ivec3 ZG = ivec3(12, 8, 12);
// Fernfeld = Breitenband FAR_OBEN..FAR_UNTEN Grad (portale_voxel.py)
const int FAR_B = 2048;
const int FAR_H = 384;
const float FAR_OBEN = 0.20943951;
const float FAR_UNTEN = -0.90757121;
// Schrittgrenzen je Modus (Plan 2.4)
const int GRENZE_FENSTER = 128;
const int GRENZE_DRIN = 128;
const int GRENZE_ANKUNFT = 96;
// Fernstufe (Plan 2.6): ab diesem Pixel-Fussabdruck (Texel je Pixel) Mittelfarbe statt Textur, Laub geschlossen
const float LOD_FUSS = 2.5;
// Umgebungsverdeckung nur bis zu diesem Fussabdruck (Texel je Pixel)
const float AO_FUSS = 0.9;
const vec3 SONNE = vec3(0.42, 0.82, 0.38);
const vec3 BLOCKLICHT = vec3(1.0, 0.86, 0.68);

float tageslicht = 1.0;
int heatSchritte = 0;

int b8(float f) {
    return int(f * 255.0 + 0.5);
}

// ---------- Szenen-Texturen ----------

vec4 voxelT(int s, ivec3 c) {
    return texelFetch(VoxelsSampler, ivec2(c.x + (c.y & 7) * 96, c.z + (c.y >> 3) * 96 + s * 768), 0);
}

int palId(vec4 t) {
    return b8(t.r) + b8(t.b) * 256;
}

vec4 pal(int s, int id, int i) {
    return texelFetch(PaletteSampler, ivec2(i, s * 512 + id), 0);
}

bool drin(ivec3 c) {
    return all(greaterThanEqual(c, ivec3(0))) && all(lessThan(c, GR));
}

float metaWert(int s, int i) {
    ivec3 b = ivec3(round(texelFetch(MetaSampler, ivec2(i, s), 0).rgb * 255.0));
    return float((b.r << 16) | (b.g << 8) | b.b) / 256.0 - 32768.0;
}

vec4 metaFarbe(int s, int i) {
    return texelFetch(MetaSampler, ivec2(i, s), 0);
}

// Kachel der Flaeche: 0 oben, 1 unten, 2 nord, 3 sued, 4 ost, 5 west
int kachel(int s, int id, int flaeche) {
    vec4 p = pal(s, id, flaeche >> 1);
    return (flaeche & 1) == 0 ? b8(p.r) * 256 + b8(p.g) : b8(p.b) * 256 + b8(p.a);
}

vec4 atlas(int k, vec2 st) {
    ivec2 l = clamp(ivec2(floor(st * 16.0)), ivec2(0), ivec2(15));
    return texelFetch(AtlasSampler, ivec2((k & 31) * 16, (k >> 5) * 16) + l, 0);
}

// 4-Tap-Mittel bei grossem Pixel-Fussabdruck (Hugo _qi3)
vec4 atlasGefiltert(int k, vec2 st, float fuss) {
    vec4 mitte = atlas(k, st);
    if (fuss <= 1.5)
        return mitte;
    float o = min(fuss, 8.0) / 64.0;
    vec4 a = atlas(k, st + vec2(o, 0.5 * o));
    vec4 b = atlas(k, st + vec2(-0.5 * o, o));
    vec4 c = atlas(k, st + vec2(-o, -0.5 * o));
    vec4 d = atlas(k, st + vec2(0.5 * o, -o));
    float gewicht = a.a + b.a + c.a + d.a;
    vec3 summe = a.rgb * a.a + b.rgb * b.a + c.rgb * c.a + d.rgb * d.a;
    return vec4(gewicht > 0.001 ? summe / gewicht : mitte.rgb, 0.25 * gewicht);
}

// ---------- Geometrie ----------

vec3 minAchse(vec3 v) {
    if (v.x < v.y)
        return v.x < v.z ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 0.0, 1.0);
    return v.y < v.z ? vec3(0.0, 1.0, 0.0) : vec3(0.0, 0.0, 1.0);
}

vec3 maxAchse(vec3 v) {
    if (v.x > v.y)
        return v.x > v.z ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 0.0, 1.0);
    return v.y > v.z ? vec3(0.0, 1.0, 0.0) : vec3(0.0, 0.0, 1.0);
}

ivec3 zelleVon(vec3 p, vec3 dir) {
    return ivec3(mix(ceil(p) - 1.0, floor(p), step(0.0, dir)));
}

// Flaechen-Index und Textur-Koordinate aus Normale + lokaler Lage (Vanilla-Ausrichtung)
int flaecheVon(vec3 n, vec3 l, out vec2 st) {
    if (n.y > 0.5) { st = vec2(l.x, l.z); return 0; }
    if (n.y < -0.5) { st = vec2(l.x, 1.0 - l.z); return 1; }
    if (n.z < -0.5) { st = vec2(1.0 - l.x, 1.0 - l.y); return 2; }
    if (n.z > 0.5) { st = vec2(l.x, 1.0 - l.y); return 3; }
    if (n.x > 0.5) { st = vec2(1.0 - l.z, 1.0 - l.y); return 4; }
    st = vec2(l.z, 1.0 - l.y);
    return 5;
}

/*
 * Kreuz (Pflanzen) in einer Zelle (Hugo _qin Form 4): zwei senkrechte Diagonalflaechen. Eintritt ent (lokal 0..1),
 * Spanne bis zum Zellausgang. pick 0 = erste Flaeche, 1 = zweite (wenn die erste per Alpha durchfiel).
 */
bool kreuzTreffer(int pick, vec3 ent, vec3 dir, float spanne, out float s, out vec3 n) {
    s = 0.0;
    n = vec3(0.0, 1.0, 0.0);
    float da = dir.x - dir.z;
    float db = dir.x + dir.z;
    float sa = abs(da) > 1.0e-6 ? (ent.z - ent.x) / da : -1.0;
    float sb = abs(db) > 1.0e-6 ? (1.0 - ent.x - ent.z) / db : -1.0;
    bool va = sa >= 0.0 && sa <= spanne;
    bool vb = sb >= 0.0 && sb <= spanne;
    bool ersteA = va && (!vb || sa <= sb);
    bool nimmA = ersteA;
    if (pick == 0) {
        if (!va && !vb)
            return false;
    } else {
        if (!va || !vb)
            return false;
        nimmA = !ersteA;
    }
    s = nimmA ? sa : sb;
    vec3 ebene = nimmA ? vec3(0.70710678, 0.0, -0.70710678) : vec3(0.70710678, 0.0, 0.70710678);
    n = dot(ebene, dir) > 0.0 ? -ebene : ebene;
    return true;
}

bool boxTreffer(vec3 lo, vec3 hi, vec3 ent, vec3 inv, vec3 sgn, float spanne, vec3 eintritt, out float s, out vec3 n) {
    s = 0.0;
    n = eintritt;
    vec3 ta = (lo - ent) * inv;
    vec3 tb = (hi - ent) * inv;
    vec3 tn = min(ta, tb);
    vec3 tf = max(ta, tb);
    float a = max(max(tn.x, tn.y), tn.z);
    float b = min(min(tf.x, tf.y), tf.z);
    if (a > b || b < 0.0 || a > spanne)
        return false;
    if (a > 0.0) {
        s = a;
        n = -maxAchse(tn) * sgn;
    }
    return true;
}

void boxGrenzen(int s, int id, out vec3 lo, out vec3 hi) {
    ivec3 b = ivec3(round(pal(s, id, 3).rgb * 255.0));
    lo = vec3(float(b.r >> 4), float(b.r & 15), float(b.g >> 4)) / 16.0;
    hi = (vec3(float(b.g & 15), float(b.b >> 4), float(b.b & 15)) + 1.0) / 16.0;
}

// ---------- Licht ----------
// Vanilla 26.1/26.2 core/lightmap.fsh mit den Werten der Overworld (data/minecraft/timeline/day.json,
// EnvironmentAttributes): Himmelslicht-Faktor 1.0 (Tag) .. 0.24 (Nacht), Himmelslicht-Farbe weiss .. #7a7aff,
// Umgebung #0a0a0a, Blocklicht-Toenung #ffd88c, Blocklicht x1.4, Helligkeits-Option 0.5 (Standard). Pruefer
// 21.10.2026: die Nacht-Szene war viel dunkler als die echte Welt (Luma 40 statt 72) — alte Formel zog 11 Stufen ab.

float lmHell(float stufe) {
    float l = clamp(stufe / 15.0, 0.0, 1.0);
    return l / (4.0 - 3.0 * l);
}

vec3 lichtFarbe(vec2 stufe) {
    float t = tageslicht;
    vec3 c = vec3(10.0 / 255.0);
    c += mix(vec3(122.0 / 255.0, 122.0 / 255.0, 1.0), vec3(1.0), t) * (lmHell(stufe.x) * mix(0.24, 1.0, t));
    float bl = clamp(stufe.y / 15.0, 0.0, 1.0);
    float para = (2.0 * bl - 1.0) * (2.0 * bl - 1.0);
    c += mix(vec3(1.0, 216.0 / 255.0, 140.0 / 255.0), vec3(1.0), 0.9 * para) * (lmHell(stufe.y) * 1.4);
    c = clamp(c, 0.0, 1.0);
    float m = max(max(c.r, c.g), max(c.b, 1.0e-4));
    float inv = 1.0 - m;
    vec3 ohneGamma = c * ((1.0 - inv * inv * inv * inv) / m);
    return mix(c, ohneGamma, 0.5);
}

// Himmel-/Blocklicht der Zelle + "fest" (Block ohne Licht = verdeckt fuer die Umgebungsverdeckung)
vec3 zellLicht(int s, ivec3 c) {
    if (!drin(c))
        return vec3(15.0, 0.0, 0.0);
    vec4 t = voxelT(s, c);
    int g = b8(t.g);
    return vec3(float(g >> 4), float(g & 15), palId(t) != 0 && g == 0 ? 1.0 : 0.0);
}

vec3 eckLicht(vec3 a, vec3 b, vec3 c, vec3 d) {
    vec4 offen = vec4(1.0) - vec4(a.z, b.z, c.z, d.z);
    float anzahl = offen.x + offen.y + offen.z + offen.w;
    vec2 summe = a.xy * offen.x + b.xy * offen.y + c.xy * offen.z + d.xy * offen.w;
    return vec3(summe / max(anzahl, 1.0), 1.0 - 0.2 * (4.0 - anzahl));
}

// 9-Punkt-Licht mit Umgebungsverdeckung auf einer Vollblock-Flaeche
vec3 weichesLicht(int s, ivec3 vor, vec3 n, vec3 l) {
    ivec3 e1 = abs(n.x) > 0.5 ? ivec3(0, 1, 0) : ivec3(1, 0, 0);
    ivec3 e2 = abs(n.z) > 0.5 ? ivec3(0, 1, 0) : ivec3(0, 0, 1);
    vec2 st = abs(n.x) > 0.5 ? l.yz : (abs(n.y) > 0.5 ? l.xz : l.xy);
    vec3 c = zellLicht(s, vor);
    vec3 xm = zellLicht(s, vor - e1);
    vec3 xp = zellLicht(s, vor + e1);
    vec3 ym = zellLicht(s, vor - e2);
    vec3 yp = zellLicht(s, vor + e2);
    vec3 c00 = eckLicht(c, xm, ym, zellLicht(s, vor - e1 - e2));
    vec3 c10 = eckLicht(c, xp, ym, zellLicht(s, vor + e1 - e2));
    vec3 c01 = eckLicht(c, xm, yp, zellLicht(s, vor - e1 + e2));
    vec3 c11 = eckLicht(c, xp, yp, zellLicht(s, vor + e1 + e2));
    return mix(mix(c00, c10, st.x), mix(c01, c11, st.x), st.y);
}

vec3 beleuchtet(int s, vec3 albedo, vec2 stufe, float verdeckung, vec3 n, float schattierung) {
    // Aufnahme-Faktor (Meta 11, 1.0 = Tag) skaliert das gespeicherte Himmelslicht
    vec2 st = vec2(stufe.x * metaWert(s, 11), stufe.y);
    return albedo * lichtFarbe(st) * schattierung * verdeckung;
}

// Farbe einer getroffenen Flaeche (Textur bzw. Mittelfarbe, Toenung, Licht)
vec4 flaechenFarbe(int s, ivec3 c, vec3 n, vec3 l, int id, float fuss) {
    vec4 p5 = pal(s, id, 5);
    int form = b8(p5.r);
    int flags = b8(p5.g);
    vec2 st;
    int f = flaecheVon(n, l, st);
    vec4 farbe;
    bool toenen = f == 0 ? (flags & 1) != 0 : (f == 1 ? (flags & 4) != 0 : (flags & 2) != 0);
    if (form == 2)
        toenen = (flags & 2) != 0;
    if (fuss > LOD_FUSS && form != 3) {
        // Fern: Mittelfarbe der Flaeche (schon getoent), Laub geschlossen, Glas behaelt seine Deckung
        vec4 mittel = pal(s, id, f <= 1 ? 6 : 7);
        farbe = vec4(mittel.rgb, (flags & 64) != 0 ? mittel.a : 1.0);
        toenen = false;
    } else {
        if (form == 2)
            st = vec2(l.x, 1.0 - l.y);
        farbe = atlasGefiltert(kachel(s, id, form == 2 ? 2 : f), st, fuss);
    }
    if (toenen)
        farbe.rgb *= pal(s, id, 4).rgb;
    if ((flags & 16) != 0)
        return vec4(farbe.rgb, farbe.a);
    vec2 stufe;
    float verdeckung = 1.0;
    vec3 lo, hi;
    boxGrenzen(s, id, lo, hi);
    bool vollblock = form == 1 && all(lessThan(lo, vec3(0.01))) && all(greaterThan(hi, vec3(0.99)));
    // Umgebungsverdeckung (9 Zellen) nur nah — weiter weg ist sie kleiner als ein Bildpunkt (Pruefer: C1 +48 %)
    if (vollblock && fuss < AO_FUSS) {
        vec3 w = weichesLicht(s, c + ivec3(round(n)), n, l);
        stufe = w.xy;
        verdeckung = w.z;
    } else {
        vec3 a = zellLicht(s, c);
        vec3 b = zellLicht(s, c + ivec3(round(n)));
        stufe = max(a.xy, b.xy);
    }
    float schatt = form == 2 ? 1.0 : (abs(n.y) > 0.5 ? (n.y > 0.0 ? 1.0 : 0.5) : (abs(n.x) > 0.5 ? 0.6 : 0.8));
    return vec4(beleuchtet(s, farbe.rgb, stufe, verdeckung, n, schatt), farbe.a);
}

// ---------- Fernfeld + Dunst ----------

vec4 farTexel(int s, int x, int y) {
    return texelFetch(FarSampler, ivec2(x, s * FAR_H + y), 0);
}

// Himmel ueber der Szene (Strahl verlaesst sie nach oben): Vanilla-Overworld sky_color #78a7ff / fog_color #c0d8ff,
// nachts fast schwarz (Pruefer 21.10.2026: grauer Dunst im Himmel der Wirbel-Szene)
vec3 himmelVerlauf(int s, vec3 d) {
    vec3 zenit = mix(vec3(0.0, 0.0, 0.012), vec3(120.0, 167.0, 255.0) / 255.0, tageslicht);
    vec3 horizont = mix(vec3(0.02, 0.025, 0.05), vec3(192.0, 216.0, 255.0) / 255.0, tageslicht);
    return d.y >= 0.0 ? mix(horizont, zenit, sqrt(clamp(d.y, 0.0, 1.0) * 1.6)) : horizont * (0.6 + 0.4 * (1.0 + d.y));
}

vec3 fern(int s, vec3 d) {
    float lon = atan(d.x, abs(d.x) + abs(d.z) < 1.0e-6 ? 1.0e-6 : d.z);
    float lat = asin(clamp(d.y, -1.0, 1.0));
    vec2 p = vec2((lon / 6.2831853 + 0.5) * float(FAR_B) - 0.5, (lat - FAR_OBEN) / (FAR_UNTEN - FAR_OBEN) * float(FAR_H) - 0.5);
    vec2 basis = floor(p);
    vec2 f = p - basis;
    int x0 = int(basis.x);
    x0 = x0 < 0 ? x0 + FAR_B : (x0 >= FAR_B ? x0 - FAR_B : x0);
    int x1 = x0 + 1 >= FAR_B ? 0 : x0 + 1;
    int y0 = clamp(int(basis.y), 0, FAR_H - 1);
    int y1 = clamp(int(basis.y) + 1, 0, FAR_H - 1);
    vec4 c;
    if (p.y > float(FAR_H) - 1.0) {
        // unter dem Band (steil nach unten aus der Szene): keine geklemmte Unterkante (Pruefer 21.10.2026: senkrechte
        // Farbstreifen im Brunnen-Fenster oben), sondern ein breites Mittel der untersten Zeile
        c = vec4(0.0);
        for (int k = -3; k <= 3; k++) {
            int xk = x0 + k * 24;
            xk = xk < 0 ? xk + FAR_B : (xk >= FAR_B ? xk - FAR_B : xk);
            c += farTexel(s, xk, FAR_H - 1);
        }
        c /= 7.0;
    } else {
        vec4 oben = mix(farTexel(s, x0, y0), farTexel(s, x1, y0), f.x);
        vec4 unten = mix(farTexel(s, x0, y1), farTexel(s, x1, y1), f.x);
        c = mix(oben, unten, f.y);
    }
    // Fernfeld-Foto ist am Tag aufgenommen: Gelaende mit dem Licht der Tageszeit (wie die Bloecke), Himmel = Verlauf
    vec3 gelaende = c.rgb / max(c.a, 1e-3) * lichtFarbe(vec2(15.0, 0.0));
    return mix(himmelVerlauf(s, d), gelaende, clamp(c.a, 0.0, 1.0));
}

vec3 dunst(int s, vec3 farbe, float weg) {
    vec4 d = metaFarbe(s, 6);
    vec3 dunstFarbe = d.rgb * lichtFarbe(vec2(15.0, 0.0));
    return mix(farbe, dunstFarbe, 1.0 - exp(-d.a * max(weg, 0.0)));
}

/*
 * DDA durch die Szene (Hugo _qiy): Ganzzahl-Schritte mit erhaltenem Vorzeichen, Ziegel nur beim Ziegelwechsel,
 * Cutout nur ueber Alpha, Schattierung einmal nach der Schleife. ro/dir in Szenen-Koordinaten (dir normiert),
 * vor = Weg Kamera -> Strahlstart (Fussabdruck), pixel = Winkelgroesse eines Pixels, grenze = max. Schritte.
 * Rueckgabe: RGB, A = 1 Treffer/Fernfeld, A = 0 Strahl ging nach oben aus der Szene (Komposit: echter Himmel).
 */
vec4 szene(int s, vec3 ro, vec3 dir, float vor, float pixel, int grenze, bool komposit) {
    vec3 sgn = vec3(dir.x >= 0.0 ? 1.0 : -1.0, dir.y >= 0.0 ? 1.0 : -1.0, dir.z >= 0.0 ? 1.0 : -1.0);
    vec3 inv = sgn / max(abs(dir), vec3(1.0e-6));
    vec3 ta = -ro * inv;
    vec3 tb = (GRF - ro) * inv;
    vec3 tn = min(ta, tb);
    vec3 tf = max(ta, tb);
    float ein = max(max(tn.x, tn.y), tn.z);
    float aus = min(min(tf.x, tf.y), tf.z);
    vec3 maske = maxAchse(tn);
    if (ein < 0.0) {
        ein = 0.0;
        maske = maxAchse(abs(dir));
    }
    vec3 schritt = step(0.0, dir);
    float t = ein;
    bool gefunden = false;
    bool glas = false;
    bool fluessig = false;
    ivec3 trefferZelle = ivec3(0);
    vec3 trefferN = vec3(0.0, 1.0, 0.0);
    int trefferId = 0;
    float trefferT = 0.0;
    ivec3 glasZelle = ivec3(0);
    vec3 glasN = vec3(0.0, 1.0, 0.0);
    int glasId = 0;
    float glasT = 0.0;
    ivec3 zelle = ivec3(0);
    bool frisch = true;
    int i = 0;
    if (ein < aus) {
        // DDA mit Ganzzahl-Schritten (Hugo): Vorzeichen bleibt erhalten, Zelle nach einem Sprung richtungsabhaengig
        // gerundet -> keine haengenden Strahlen an Blockkanten (Risslinien). Leere Zellen springen per Abstandsfeld.
        for (i = 0; i < grenze; i++) {
            if (frisch) {
                if (t >= aus)
                    break;
                vec3 p = ro + dir * t;
                vec3 nah = round(p);
                p = mix(p, nah, step(abs(p - nah), vec3(1.0e-4)));
                zelle = zelleVon(p, dir);
                if (!drin(zelle))
                    break;
                frisch = false;
            }
            vec4 v = voxelT(s, zelle);
            int id = palId(v);
            vec3 tz = (vec3(zelle) + schritt - ro) * inv;
            float tZ = min(min(tz.x, tz.y), tz.z);
            if (id == 0) {
                // Leerraum-Sprung: Wuerfel mit Chebyshev-Radius (r-1) um die Zelle ist leer (Alpha = 255 - r)
                int r = max(255 - b8(v.a), 1);
                if (r > 1) {
                    vec3 rand = vec3(zelle) + mix(vec3(float(1 - r)), vec3(float(r)), schritt);
                    vec3 te = (rand - ro) * inv;
                    maske = minAchse(te);
                    t = min(min(te.x, te.y), te.z);
                    frisch = true;
                    continue;
                }
            } else {
                vec3 ent = ro + dir * t - vec3(zelle);
                float spanne = tZ - t;
                vec3 eintritt = -maske * sgn;
                vec4 p5 = pal(s, id, 5);
                int form = b8(p5.r);
                int flags = b8(p5.g);
                for (int k = 0; k < 2; k++) {
                    float sAb;
                    vec3 n;
                    bool getroffen;
                    if (form == 2) {
                        getroffen = kreuzTreffer(k, ent, dir, spanne, sAb, n);
                    } else {
                        if (k != 0)
                            break;
                        vec3 lo, hi;
                        if (form == 3) {
                            lo = vec3(0.0);
                            hi = vec3(1.0, 0.875, 1.0);
                        } else {
                            boxGrenzen(s, id, lo, hi);
                        }
                        getroffen = boxTreffer(lo, hi, ent, inv, sgn, spanne, eintritt, sAb, n);
                    }
                    if (!getroffen)
                        break;
                    if (((flags & 64) != 0 || form == 3) && (flags & 16) == 0) {
                        // durchscheinend (Glas, Eis, Wasser): erste Schicht merken, weiterlaufen
                        if (!glas) {
                            glas = true;
                            fluessig = form == 3;
                            glasZelle = zelle;
                            glasN = n;
                            glasId = id;
                            glasT = t + sAb;
                        }
                        break;
                    }
                    if ((flags & 32) != 0 && (vor + t + sAb) * pixel * 16.0 < LOD_FUSS) {
                        // Cutout (Laub, Pflanzen, Gitter): nur Alpha testen; ab mittlerer Entfernung zweiter Tap
                        vec3 l = clamp(ent + dir * sAb, 0.0, 1.0);
                        vec2 st;
                        int f = flaecheVon(n, l, st);
                        if (form == 2)
                            st = vec2(l.x, 1.0 - l.y);
                        int kt = kachel(s, id, form == 2 ? 2 : f);
                        float alpha = atlas(kt, st).a;
                        float streu = (vor + t + sAb) * pixel;
                        if (streu > 0.0625)
                            alpha = max(alpha, atlas(kt, st + vec2(min(streu, 0.25) * 0.5)).a);
                        if (alpha < 0.5)
                            continue;
                    }
                    gefunden = true;
                    trefferZelle = zelle;
                    trefferN = n;
                    trefferId = id;
                    trefferT = t + sAb;
                    break;
                }
                if (gefunden)
                    break;
            }
            maske = minAchse(tz);
            t = tZ;
            zelle += ivec3(maske * sgn);
            if (!drin(zelle))
                break;
        }
    }
    heatSchritte = i;
    bool erschoepft = !gefunden && ein < aus && t < aus - 0.01 && i >= grenze;
    vec3 farbe;
    float weg;
    float alpha = 1.0;
    if (gefunden) {
        float fuss = (vor + trefferT) * pixel * 16.0 / max(abs(dot(dir, trefferN)), 0.25);
        vec3 l = clamp(ro + dir * trefferT - vec3(trefferZelle), 0.0, 1.0);
        farbe = flaechenFarbe(s, trefferZelle, trefferN, l, trefferId, fuss).rgb;
        weg = trefferT;
    } else if (erschoepft) {
        farbe = metaFarbe(s, 6).rgb * lichtFarbe(vec2(15.0, 0.0));
        weg = 0.0;
    } else {
        if (komposit && dir.y > -0.03)
            alpha = 0.0;
        farbe = fern(s, dir);
        weg = (ein < aus ? aus : 0.0) * (1.0 - smoothstep(0.0, 0.6, dir.y));
    }
    farbe = dunst(s, farbe, weg);
    if (glas) {
        float fuss = (vor + glasT) * pixel * 16.0 / max(abs(dot(dir, glasN)), 0.25);
        vec3 l = clamp(ro + dir * glasT - vec3(glasZelle), 0.0, 1.0);
        vec4 g = flaechenFarbe(s, glasZelle, glasN, l, glasId, fuss);
        float a = clamp(g.a, 0.0, 1.0);
        if (fluessig) {
            a = max(a, 0.55);
            float tiefe = min((gefunden ? trefferT : aus) - glasT, 24.0);
            a = 1.0 - (1.0 - a) * exp(-0.18 * max(tiefe, 0.0));
        }
        farbe = mix(farbe, dunst(s, g.rgb, glasT), a);
        alpha = 1.0;
    }
#ifdef CHAOS_HEAT
    if (i >= grenze)
        return vec4(1.0, 0.0, 1.0, 1.0);
    float h = 1.0 - exp(-metaFarbe(s, 6).a * max(weg, 0.0));
    return vec4(float(i) / float(grenze), gefunden ? h : 1.0, gefunden ? 0.25 : (glas ? 0.6 : 1.0), 1.0);
#endif
    return vec4(farbe, alpha);
}

// ---------- Portal je Block (halbe Aufloesung) ----------

/*
 * Dieser Pass laeuft in halber Aufloesung (chaos_feld.vsh mit CHAOS_HALB zeichnet ins linke untere Viertel des
 * Ziels chaos_klein): ein Pixel = 2x2 Bildpunkte. Gedeckt ist der Block, wenn einer der vier Bildpunkte exakt
 * (Flaeche, Tiefe) getroffen wird; marschiert wird mit dem Strahl durch die Blockmitte. chaos_mix setzt daraus das
 * volle Bild zusammen. Ausgabe: RGB + A = (Slot+1) | Deckungsmaske<<3 (/255), A = 0 = kein Portal (bzw. Komposit:
 * echter Himmel).
 */
void main() {
    ivec2 voll = textureSize(MainDepthSampler, 0);
    // Block = 2x2 (Stufe 1) bzw. 4x4 Bildpunkte (Stufe 2, grossflaechig)
    int bk = 1 << chaosStufe;
    ivec2 basisPx = ivec2(gl_FragCoord.xy) * bk;
    vec2 groesse = vec2(voll);
    vec2 ndcMitte = (vec2(basisPx) + 0.5 * float(bk)) / groesse * 2.0 - 1.0;
    if (basisPx.x >= voll.x || basisPx.y >= voll.y || !chaosImRechteck(ndcMitte)) {
        fragColor = vec4(0.0);
        return;
    }
    int wahl = -1;
    float bestT = 1e30;
    int slots[4];
    for (int k = 0; k < 4; k++) {
        // Deckung je Viertel des Blocks (Stufe 1: der Bildpunkt selbst, Stufe 2: Mitte des 2x2-Viertels)
        ivec2 px = min(basisPx + ivec2(k & 1, k >> 1) * (bk >> 1) + (bk >> 2), voll - 1);
        float tk;
        slots[k] = chaosWahl((vec2(px) + 0.5) / groesse * 2.0 - 1.0, texelFetch(MainDepthSampler, px, 0).r, tk);
        if (slots[k] >= 0 && tk < bestT) {
            wahl = slots[k];
            bestT = tk;
        }
    }
    if (wahl < 0) {
        fragColor = vec4(0.0);
        return;
    }
    // exakte Deckung der vier Bildpunkte (Bit k = Bildpunkt (k&1, k>>1)) fuer chaos_mix
    int maske = 0;
    for (int k = 0; k < 4; k++)
        if (slots[k] == wahl)
            maske |= 1 << k;
    int wort = chaosKopf[wahl].x;
    int form = chaosKopf[wahl].y;
    vec3 pos = chaosLage[wahl].xyz;
    vec3 d = chaosRichtung(ndcMitte);
    // Strahlstart der Blockmitte auf der Flaeche (auch knapp ausserhalb des Randes, der Rand kommt aus chaos_mix)
    float vorT = 0.0;
    if (!(form == 0 || form == 5 || chaosKopf[wahl].z == 1)) {
        vec3 n, u, w;
        basisVon(form, pos, n, u, w);
        float den = dot(d, n);
        vorT = abs(den) < 1e-7 ? bestT : max(dot(pos, n) / den, 0.0);
    }
    tageslicht = float((wort >> 21) & 7) / 7.0;
    int s = wort & 3;
    int anker = (wort >> 2) & 1;
    bool rund = ((wort >> 6) & 1) != 0;
    vec3 ankerPos = anker == 0 ? vec3(metaWert(s, 0), metaWert(s, 1), metaWert(s, 2)) : vec3(metaWert(s, 3), metaWert(s, 4), metaWert(s, 5));
    // Kamera in Szenen-Koordinaten: Marker = Anker; altes Vollbild mit "rund" = Kamera fest am Anker
    vec3 kamera = form == 0 && rund ? ankerPos : ankerPos - pos;
    if (form == 5 && GameTime < 5.0e-5) {
        // Ankunft, erstes Weltbild nach dem Respawn-Paket (Zeit der neuen Welt noch 0): die Kamera steht noch auf der alten
        // Welt — Kamera = Anker + Versatz der Ankunft (Steuerwort Bit 7-11 / 12-16 in 1/4 Block, PortalAnkunft)
        kamera = ankerPos + vec3(float(((wort >> 7) & 31) - 16) * 0.25, 0.0, float(((wort >> 12) & 31) - 16) * 0.25);
    }
    if (chaosKopf[wahl].z == 1 && form != 1 && form != 4) {
        // drin hinter einer Wand (Farmwelt-Portal): die Szenen-Kamera sinkt nie unter Augenhoehe ueber der Fensterunterkante
        // (hinter dem Portal geht es Stufen hinab — sonst saenke man in der Szene in den Boden)
        float hh = float((wort >> 12) & 31) * 0.25;
        kamera.y = ankerPos.y + max(-pos.y, 1.62 - hh);
    }
    float laenge = length(d);
    vec3 dn = d / laenge;
    float vor = vorT * laenge;
    // Winkelgroesse eines (halben) Pixels: 2 Bildpunkte
    float pixel = 2.0 * float(bk) / (abs(chaosProj.y) * groesse.y);
    int grenze = form == 5 ? GRENZE_ANKUNFT : (chaosKopf[wahl].z == 1 || form == 0 ? GRENZE_DRIN : GRENZE_FENSTER);
    vec4 farbe = szene(s, kamera + dn * vor, dn, vor, pixel, grenze, form == 5);
    fragColor = farbe.a < 0.5 ? vec4(0.0) : vec4(farbe.rgb, float((wahl + 1) | (maske << 3)) / 255.0);
}
