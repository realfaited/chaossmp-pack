#version 330

// ChaosSMP Voxel-Portale, Ultra-Plan 21.10.2026 (docs/PORTALE.md): Feld-Vertex-Shader fuer chaos_portal (mit
// CHAOS_HALB: halbe Aufloesung, linkes unteres Viertel des Ziels) und chaos_mix.
//
// Statt des Vollbild-Dreiecks (core/screenquad) zeichnet dieser Shader nur ein Dreieck um das Bildschirm-Rechteck, in
// dem ein Portal liegen kann. Pixel ausserhalb laufen gar nicht erst durch den Fragment-Shader. Ausserdem werden die
// Marker-Datenzeilen (rendertype_outline.vsh/fsh) hier EINMAL je Pass dekodiert (3 Vertices) statt in jedem Pixel und
// als flache Varyings weitergereicht. Kein Marker im Bild = entartetes Dreieck = 0 Pixel.
//
// Datenzeile je Slot (17 Spalten, exakte Floats): 0 Steuerwort<<8|0xA5, 1-3 Marker-Lage (Weltachsen relativ zur
// Kamera), 4-12 ModelView 3x3, 13-16 Projektion (P00, P11, P22, P32).
// Formen (Bit 3-5): 0 Vollbild alt, 1 Boden (Betrachter oben), 2 Wand +X, 3 Wand +Z, 4 Scheibe, 5 Ankunft (Tiefen-
// Komposit), 6 Wand -X, 7 Wand -Z.

uniform sampler2D DataSampler;

out vec2 texCoord;

flat out vec4 chaosRect;
flat out ivec4 chaosKopf[4];
flat out vec4 chaosLage[4];
flat out vec3 chaosInvX;
flat out vec3 chaosInvY;
flat out vec3 chaosInvZ;
flat out vec4 chaosProj;
// 1 = halbe Aufloesung, 2 = Viertel (Portal-Rechteck > CHAOS_VIERTEL_AB des Bildes: Fenster direkt vor dem Gesicht,
// Pruefer 21.10.: Farmwelt-Portal aus 1,5 Bloecken +48 %). Beide Paesse (chaos_portal, chaos_mix) rechnen dasselbe Rechteck -> dieselbe Stufe.
flat out int chaosStufe;
const float CHAOS_VIERTEL_AB = 0.6;

// Hinter einem Fenster (Betrachter auf der Rueckseite der Flaeche) zaehlt bis 2*Drin-Code Bloecke als "drin" (Vollbild).
// Der Drin-Code (Steuerwort Bit 17-20) kommt vom Server: 0 = nie (Hof hinter dem Farmwelt-Portal, Wartezeit, Bedrock),
// Brunnen = Schachttiefe, Farmwelt-Portal = 2 (4 Bloecke) nur fuer Spieler, die von VORN durch duerfen (Pruefer 21.10.)
const float CHAOS_DRIN_RAND = 0.6;
const float CHAOS_NAH = 0.05;

uint chaosBitsV(int spalte, int slot) {
    uvec4 b = uvec4(round(texelFetch(DataSampler, ivec2(spalte, slot), 0) * 255.0));
    return (b.r << 24u) | (b.g << 16u) | (b.b << 8u) | b.a;
}

float chaosWertV(int spalte, int slot) {
    return uintBitsToFloat(chaosBitsV(spalte, slot));
}

/*
 * Plausibel? (26.10.2026, Fall L3tekkZ/Lunar: das Portal lag als achsenparalleles Rechteck quer ueber dem Bild)
 * Die Kette braucht Position = Kamera-relative WELTachsen und ModelViewMat = Kamera-Drehung. Ein Client, der die Drehung
 * schon in die Vertices rechnet (ModelViewMat = Einheit), liefert eine "Lage" in Sichtachsen — dann lieber kein Portal
 * als ein falsches. Einheit genau trifft ein echter Spieler praktisch nie (Blick exakt Nord, Neigung exakt 0); dann
 * fehlt das Portal fuer dieses eine Bild. Ausserdem: Drehung orthonormal, Werte endlich, Projektion plausibel.
 */
bool chaosDatenGut(mat3 v, vec3 pos, vec4 pr) {
    for (int k = 0; k < 3; k++)
        if (any(isnan(v[k])) || any(isinf(v[k])))
            return false;
    if (any(isnan(pos)) || any(isinf(pos)) || any(isnan(pr)) || any(isinf(pr)) || dot(pos, pos) > 1.0e6)
        return false;
    mat3 e = v - mat3(1.0);
    if (dot(e[0], e[0]) + dot(e[1], e[1]) + dot(e[2], e[2]) < 1.0e-10)
        return false;
    mat3 o = transpose(v) * v - mat3(1.0);
    if (dot(o[0], o[0]) + dot(o[1], o[1]) + dot(o[2], o[2]) > 1.0e-3 || determinant(v) < 0.9)
        return false;
    return pr.x > 0.0 && pr.y > 0.0;
}

// Flaechenbasis je Form: n = Normale zur Betrachterseite, u/w = Achsen der Flaeche
void chaosBasis(int form, vec3 pos, out vec3 n, out vec3 u, out vec3 w) {
    u = vec3(1.0, 0.0, 0.0);
    w = vec3(0.0, 0.0, 1.0);
    n = vec3(0.0, 1.0, 0.0);
    if (form == 2 || form == 6) {
        n = vec3(form == 2 ? 1.0 : -1.0, 0.0, 0.0);
        u = vec3(0.0, 0.0, 1.0);
        w = vec3(0.0, 1.0, 0.0);
    } else if (form == 3 || form == 7) {
        n = vec3(0.0, 0.0, form == 3 ? 1.0 : -1.0);
        u = vec3(1.0, 0.0, 0.0);
        w = vec3(0.0, 1.0, 0.0);
    } else if (form == 4) {
        vec2 h = pos.xz;
        n = dot(h, h) < 1e-8 ? vec3(0.0, 0.0, 1.0) : -normalize(vec3(h.x, 0.0, h.y));
        u = vec3(-n.z, 0.0, n.x);
        w = vec3(0.0, 1.0, 0.0);
    }
}

void main() {
    vec2 bild = vec2(textureSize(DataSampler, 0));
    vec4 rect = vec4(2.0, 2.0, -2.0, -2.0);
    bool irgendeins = false;
    bool einDrin = false;
    mat3 view = mat3(1.0);
    vec4 proj = vec4(1.0, 1.0, 0.0, 0.0);
    for (int slot = 0; slot < 4; slot++) {
        chaosKopf[slot] = ivec4(-1, 0, 0, 0);
        chaosLage[slot] = vec4(0.0);
        uint kopf = chaosBitsV(0, slot);
        if ((kopf & 255u) != 0xA5u)
            continue;
        int wort = int(kopf >> 8u);
        vec4 pr = vec4(chaosWertV(13, slot), chaosWertV(14, slot), chaosWertV(15, slot), chaosWertV(16, slot));
        if (abs(pr.x) < 1e-6 || abs(pr.y) < 1e-6 || (wort & 3) > 2)
            continue;
        vec3 pos = vec3(chaosWertV(1, slot), chaosWertV(2, slot), chaosWertV(3, slot));
        mat3 v;
        for (int k = 0; k < 9; k++)
            v[k / 3][k % 3] = chaosWertV(4 + k, slot);
        if (!chaosDatenGut(v, pos, pr))
            continue;
        view = v;
        proj = pr;
        int form = (wort >> 3) & 7;
        float hb = float((wort >> 7) & 31) * 0.25;
        float hh = float((wort >> 12) & 31) * 0.25;
        bool voll = form == 0 || form == 5;
        bool drin = false;
        if (!voll) {
            vec3 n, u, w;
            chaosBasis(form, pos, n, u, w);
            vec3 auge = -pos;
            float vor = dot(auge, n);
            // Rueckseite eines Fensters, seitlich in der Flaeche: Kamera ist "drin" -> Vollbild (Hineinlaufen/-fallen)
            float drinTiefe = 2.0 * float((wort >> 17) & 15);
            if (form != 4 && vor < 0.0 && vor > -drinTiefe
                    && abs(dot(auge, u)) < hb + CHAOS_DRIN_RAND && abs(dot(auge, w)) < hh + CHAOS_DRIN_RAND) {
                voll = true;
                drin = true;
                einDrin = true;
            } else if (form == 4 && drinTiefe > 0.0 && dot(pos.xz, pos.xz) < 1.21 && abs(pos.y) < hh) {
                // Wirbel-Scheibe: Kamera in der Scheibe (Durchgang) -> Vollbild mit der echten Kamera (Ultra 3)
                voll = true;
                drin = true;
                einDrin = true;
            } else if (form != 4 && vor < 0.0) {
                // Rueckseite (Hof hinter dem Farmwelt-Portal, unter dem Brunnen ohne Drin): kein Fenster, echte Welt
                continue;
            } else {
                // Viereck an der nahen Ebene abschneiden, dann projizieren (ganz hinter der Kamera = unsichtbar)
                vec3 e[4];
                for (int k = 0; k < 4; k++)
                    e[k] = v * (pos + u * hb * ((k == 1 || k == 2) ? 1.0 : -1.0) + w * hh * (k >= 2 ? 1.0 : -1.0));
                vec4 r = vec4(2.0, 2.0, -2.0, -2.0);
                int sichtbar = 0;
                for (int k = 0; k < 4; k++) {
                    vec3 a = e[k];
                    vec3 b = e[(k + 1) & 3];
                    bool av = a.z < -CHAOS_NAH;
                    bool bv = b.z < -CHAOS_NAH;
                    if (av) {
                        vec2 q = vec2(pr.x * a.x, pr.y * a.y) / -a.z;
                        r = vec4(min(r.xy, q), max(r.zw, q));
                        sichtbar++;
                    }
                    if (av != bv) {
                        vec3 c = mix(a, b, (-CHAOS_NAH - a.z) / (b.z - a.z));
                        vec2 q = vec2(pr.x * c.x, pr.y * c.y) / CHAOS_NAH;
                        r = vec4(min(r.xy, q), max(r.zw, q));
                        sichtbar++;
                    }
                }
                if (sichtbar == 0)
                    continue;
                rect = vec4(min(rect.xy, r.xy), max(rect.zw, r.zw));
            }
        }
        if (voll)
            rect = vec4(-1.0, -1.0, 1.0, 1.0);
        irgendeins = true;
        chaosKopf[slot] = ivec4(wort, form, drin ? 1 : 0, 0);
        chaosLage[slot] = vec4(pos, 0.0);
    }
    // Rand: 2 Bildpunkte (Kanten, Rundung); der Halb-Pass 4 mehr, damit chaos_mix an der Kante nie einen Block liest,
    // den chaos_portal in diesem Bild nicht geschrieben hat
    // Stufe aus dem Rechteck OHNE Rand (26.10.2026): der Rand ist in beiden Paessen verschieden (12 vs 4 Bildpunkte) —
    // knapp an der Schwelle wählte chaos_portal sonst Viertel-, chaos_mix Halb-Aufloesung und las Bloecke, die in
    // diesem Bild niemand geschrieben hat (persistentes chaos_klein = altes Bild an falscher Stelle).
    vec2 rg = clamp(rect.zw, vec2(-1.0), vec2(1.0)) - clamp(rect.xy, vec2(-1.0), vec2(1.0));
    // Innen-Modus (Fall durch den Brunnen, Schritt durchs Farmwelt-Portal) bleibt bei halber Aufloesung: dort schaut
    // man hin, und er liegt im Budget (I +52 % bei Ziel +100 %)
    chaosStufe = !einDrin && rg.x * rg.y > CHAOS_VIERTEL_AB * 4.0 ? 2 : 1;
#ifdef CHAOS_HALB
    vec2 rand = 12.0 / bild;
#else
    vec2 rand = 4.0 / bild;
#endif
    rect = vec4(max(rect.xy - rand, vec2(-1.0)), min(rect.zw + rand, vec2(1.0)));
    if (!irgendeins || rect.z <= rect.x || rect.w <= rect.y) {
        gl_Position = vec4(-3.0, -3.0, 0.0, 1.0);
        texCoord = vec2(0.0);
        chaosRect = vec4(2.0, 2.0, -2.0, -2.0);
    } else {
        vec2 lo = rect.xy;
        vec2 hi = rect.zw;
        vec2 ecke = gl_VertexID == 0 ? lo : (gl_VertexID == 1 ? vec2(2.0 * hi.x - lo.x, lo.y) : vec2(lo.x, 2.0 * hi.y - lo.y));
#ifdef CHAOS_HALB
        // halbe (Viertel-)Aufloesung: ins linke untere Viertel (Sechzehntel) des Ziels (texCoord bleibt im vollen Bildraum)
        float m = chaosStufe == 2 ? 0.25 : 0.5;
        gl_Position = vec4(ecke * m + (m - 1.0), 0.0, 1.0);
#else
        gl_Position = vec4(ecke, 0.0, 1.0);
#endif
        texCoord = ecke * 0.5 + 0.5;
        chaosRect = rect;
    }
    mat3 inv = inverse(view);
    chaosInvX = inv[0];
    chaosInvY = inv[1];
    chaosInvZ = inv[2];
    chaosProj = proj;
}
