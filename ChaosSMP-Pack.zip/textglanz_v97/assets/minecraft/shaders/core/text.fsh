#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
layout(location = 4) in float chaosGlanzAn;
layout(location = 5) in vec2 chaosLokal;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

// ChaosSMP Rang-Glanz (resourcepack/textglanz_pack.py)
vec3 chaosGlanz(vec3 basis, vec2 lokal) {
    float t = mod(GameTime * 1200.0, 5.0);
    float pos = -1.5 + t * 4.50;
    float d = lokal.x + lokal.y * 0.80 - pos;
    float haupt = exp(-(d * d) / (0.55 * 0.55));
    float nach = 0.5 * exp(-((d + 0.9) * (d + 0.9)) / (0.16 * 0.16));
    float k = clamp(haupt + nach, 0.0, 1.0);
    vec3 metall = clamp(basis * (1.10 - 0.20 * lokal.y), 0.0, 1.0);
    return mix(metall, vec3(1.0), k * 0.85);
}

void main() {
    #ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
    #else
    vec4 texColor = texture(Sampler0, texCoord0);
    #endif

    vec4 color = texColor * vertexColor * ColorModulator;

    if (color.a < 0.1) {
        discard;
    }

    if (chaosGlanzAn > 0.5) {
        color.rgb = chaosGlanz(color.rgb, chaosLokal);
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
