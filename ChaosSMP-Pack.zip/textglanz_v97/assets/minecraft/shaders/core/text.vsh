#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:globals.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;
layout(location = 4) out float chaosGlanzAn;
layout(location = 5) out float chaosOben;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;

    // Rang-Glanz: Muster in den unteren 4 Bit der Textfarbe (R=11, G=5, B=13)
    ivec3 c = ivec3(round(Color.rgb * 255.0));
    chaosGlanzAn = ((c.r & 15) == 11 && (c.g & 15) == 5 && (c.b & 15) == 13) ? 1.0 : 0.0;
    // Glyphen-Ecken: 0 oben links, 1 unten links, 2 unten rechts, 3 oben rechts
    int ecke = gl_VertexID % 4;
    chaosOben = (ecke == 0 || ecke == 3) ? 1.0 : 0.0;
}
