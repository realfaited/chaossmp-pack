#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;
in vec2 texCoord0;
in float chaosGlanzAn;
in vec2 chaosLokal;
flat in ivec4 chaosInfo;
in vec4 chaosRandA;
in vec4 chaosRandB;
in vec4 chaosOrt;
in vec2 chaosPos;
in vec4 chaosLicht;

out vec4 fragColor;

// ChaosSMP Rang-Glanz (resourcepack/textglanz_pack.py)
vec3 chaosGlanz(vec3 basis, vec2 lokal) {
    float t = mod(GameTime * 1200.0, 5.0);
    float pos = -1.5 + t * 4.50;
    float d = lokal.x + lokal.y * 0.80 - pos;
    float haupt = exp(-(d * d) / (0.55 * 0.55));
    float nach = 0.5 * exp(-((d + 0.9) * (d + 0.9)) / (0.16 * 0.16));
    float k = clamp(haupt + nach, 0.0, 1.0);
    vec3 metall = clamp(basis * (1.10 - 0.20 * lokal.y), 0.0, 1.0);
    return mix(metall, vec3(1.0), k * 0.85);
}

// ===== ChaosSMP Text-Effekte (resourcepack/textglanz_pack.py, Vorlage Spheya „Very Cool Text Effects") =====
float chaosZufall(float s) {
    return fract(sin(s) * 43758.5453);
}

float chaosZufall2(vec2 s) {
    return fract(sin(dot(s, vec2(12.9898, 78.233))) * 43758.5453);
}

float chaosRausch(float n) {
    float i = floor(n);
    return mix(chaosZufall(i), chaosZufall(i + 1.0), smoothstep(0.0, 1.0, fract(n)));
}

float chaosRausch2(vec2 p) {
    vec2 ip = floor(p);
    vec2 u = fract(p);
    u = u * u * (3.0 - 2.0 * u);
    float r = mix(mix(chaosZufall2(ip), chaosZufall2(ip + vec2(1.0, 0.0)), u.x),
                  mix(chaosZufall2(ip + vec2(0.0, 1.0)), chaosZufall2(ip + vec2(1.0, 1.0)), u.x), u.y);
    return r * r;
}

vec3 chaosHsv(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

// Effekt-Tabelle (generiert aus resourcepack/textglanz_pack.py EFFEKTE)
const int CHAOS_FX_WACKELN = 1;
const int CHAOS_FX_WELLE = 2;
const int CHAOS_FX_HUEPFEN = 4;
const int CHAOS_FX_DREHEN = 8;
const int CHAOS_FX_KIPPEN = 16;
const int CHAOS_FX_PULSIEREN = 32;
const int CHAOS_FX_VERLAUF = 64;
const int CHAOS_FX_REGENBOGEN = 128;
const int CHAOS_FX_METALL = 256;
const int CHAOS_FX_UEBERGANG = 512;
const int CHAOS_FX_SCHIMMER = 1024;
const int CHAOS_FX_BLINKEN = 2048;
const int CHAOS_FX_UMRISS = 4096;
const int CHAOS_FX_FEINUMRISS = 8192;
const int CHAOS_FX_LEUCHTEN = 16384;
const int CHAOS_FX_FEUER = 32768;
const int CHAOS_FX_GLITCH = 65536;
const int CHAOS_FX_OHNE_SCHATTEN = 131072;
const int CHAOS_FX_RAND = 126976;
const float CHAOS_RAND = 2.0;
int chaosEffektId(int k) {
    switch (k) {
        case 4980: return 4; // DREHEN Text
        case 4981: return 16; // LEUCHTEN Text
        case 6036: return 3; // HUEPFEN Text
        case 6037: return 10; // SCHIMMER Text
        case 6038: return 14; // BLINKEN Text
        case 7548: return 5; // KIPPEN Text
        case 10928: return 12; // METALL Text
        case 15428: return 13; // FEUER Text
        case 15700: return 1; // WACKELN Text
        case 15701: return 7; // UMRISS Text
        case 15740: return 9; // REGENBOGEN Text
        case 15948: return 6; // PULSIEREN Text
        case 16268: return 2; // WELLE Text
        case 16269: return 15; // UEBERGANG Text
        case 16284: return 8; // VERLAUF Text
        case 16380: return 11; // GLITCH Text
        case 16381: return 17; // FEINUMRISS Text
        case 17748: return 3; // HUEPFEN Schatten
        case 17749: return 10; // SCHIMMER Schatten
        case 17750: return 14; // BLINKEN Schatten
        case 18592: return 5; // KIPPEN Schatten
        case 18724: return 4; // DREHEN Schatten
        case 18725: return 16; // LEUCHTEN Schatten
        case 20752: return 11; // GLITCH Schatten
        case 20753: return 17; // FEINUMRISS Schatten
        case 20756: return 12; // METALL Schatten
        case 21588: return 9; // REGENBOGEN Schatten
        case 22528: return 13; // FEUER Schatten
        case 22612: return 1; // WACKELN Schatten
        case 22613: return 7; // UMRISS Schatten
        case 22660: return 8; // VERLAUF Schatten
        case 22724: return 6; // PULSIEREN Schatten
        case 25796: return 2; // WELLE Schatten
        case 25797: return 15; // UEBERGANG Schatten
        default: return 0;
    }
}
int chaosFx(int id) {
    switch (id) {
        case 1: return 1; // WACKELN
        case 2: return 2; // WELLE
        case 3: return 4; // HUEPFEN
        case 4: return 8; // DREHEN
        case 5: return 16; // KIPPEN
        case 6: return 32; // PULSIEREN
        case 7: return 4096; // UMRISS
        case 8: return 64; // VERLAUF
        case 9: return 128; // REGENBOGEN
        case 10: return 1024; // SCHIMMER
        case 11: return 196608; // GLITCH
        case 12: return 256; // METALL
        case 13: return 32768; // FEUER
        case 14: return 2048; // BLINKEN
        case 15: return 512; // UEBERGANG
        case 16: return 147456; // LEUCHTEN
        case 17: return 8192; // FEINUMRISS
        default: return 0;
    }
}
void chaosFarben(int id, out vec3 c1, out vec3 c2, out vec3 c3) {
    c1 = vec3(1.0);
    c2 = vec3(1.0);
    c3 = vec3(0.25);
    switch (id) {
        case 1: c1 = vec3(1.0000, 0.3216, 0.3216); c2 = vec3(1.0000, 0.3216, 0.3216); c3 = vec3(0.3922, 0.0784, 0.3137); break; // WACKELN
        case 2: c1 = vec3(1.0000, 0.9216, 0.2353); c2 = vec3(1.0000, 0.9216, 0.2353); c3 = vec3(0.5882, 0.2353, 0.1176); break; // WELLE
        case 3: c1 = vec3(0.3373, 0.9216, 0.3373); c2 = vec3(0.3373, 0.9216, 0.3373); c3 = vec3(0.0784, 0.3137, 0.3529); break; // HUEPFEN
        case 4: c1 = vec3(0.2902, 0.8706, 0.8196); c2 = vec3(0.2902, 0.8706, 0.8196); c3 = vec3(0.1451, 0.2784, 0.5882); break; // DREHEN
        case 5: c1 = vec3(0.4784, 0.3137, 0.9843); c2 = vec3(0.4784, 0.3137, 0.9843); c3 = vec3(0.1569, 0.1569, 0.5490); break; // KIPPEN
        case 6: c1 = vec3(1.0000, 0.5882, 0.2353); c2 = vec3(1.0000, 0.5882, 0.2353); c3 = vec3(0.4314, 0.1961, 0.0784); break; // PULSIEREN
        case 7: c1 = vec3(1.0000, 0.3216, 0.3216); c2 = vec3(0.3922, 0.0784, 0.3137); c3 = vec3(0.3922, 0.0784, 0.3137); break; // UMRISS
        case 8: c1 = vec3(1.0000, 0.9216, 0.4706); c2 = vec3(1.0000, 0.3216, 0.3216); c3 = vec3(0.3922, 0.1569, 0.1176); break; // VERLAUF
        case 9: c1 = vec3(1.0000, 0.3333, 1.0000); c2 = vec3(1.0000, 0.3333, 1.0000); c3 = vec3(0.3137, 0.0784, 0.3137); break; // REGENBOGEN
        case 10: c1 = vec3(0.3373, 0.9216, 0.3373); c2 = vec3(0.3373, 0.9216, 0.3373); c3 = vec3(0.0784, 0.3137, 0.3529); break; // SCHIMMER
        case 11: c1 = vec3(1.0000, 1.0000, 1.0000); c2 = vec3(1.0000, 1.0000, 1.0000); c3 = vec3(0.2745, 0.2745, 0.2745); break; // GLITCH
        case 12: c1 = vec3(0.6275, 0.6275, 0.7843); c2 = vec3(0.6275, 0.6275, 0.7843); c3 = vec3(0.2510, 0.2510, 0.3529); break; // METALL
        case 13: c1 = vec3(1.0000, 0.0784, 0.0784); c2 = vec3(1.0000, 0.0784, 0.0784); c3 = vec3(0.3922, 0.0392, 0.0392); break; // FEUER
        case 14: c1 = vec3(0.3373, 0.9216, 0.3373); c2 = vec3(0.3373, 0.9216, 0.3373); c3 = vec3(0.0784, 0.3137, 0.3529); break; // BLINKEN
        case 15: c1 = vec3(1.0000, 0.9216, 0.2353); c2 = vec3(0.3373, 0.9216, 0.3373); c3 = vec3(0.5882, 0.2353, 0.1176); break; // UEBERGANG
        case 16: c1 = vec3(0.2902, 0.8706, 0.8196); c2 = vec3(1.0000, 1.0000, 1.0000); c3 = vec3(0.1451, 0.2784, 0.5882); break; // LEUCHTEN
        case 17: c1 = vec3(1.0000, 1.0000, 1.0000); c2 = vec3(1.0000, 0.6667, 0.0000); c3 = vec3(0.2745, 0.2745, 0.2745); break; // FEINUMRISS
        default: break;
    }
}

vec2 chaosUvMin;
vec2 chaosUvMax;

bool chaosAussen(vec2 uv) {
    return uv.x < chaosUvMin.x + 0.0001 || uv.y < chaosUvMin.y + 0.0001 || uv.x > chaosUvMax.x - 0.0001 || uv.y > chaosUvMax.y - 0.0001;
}

vec4 chaosTex(vec2 uv) {
    if (chaosAussen(uv))
        return vec4(0.0);
#ifdef IS_GRAYSCALE
    return texture(Sampler0, uv).rrrr;
#else
    return texture(Sampler0, uv);
#endif
}

bool chaosNachbar(vec2 uv, float schritt) {
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            if (x == 0 && y == 0)
                continue;
            if (chaosTex(uv + vec2(float(x), float(y)) * schritt / 256.0).a >= 0.1)
                return true;
        }
    }
    return false;
}

float chaosAbstand(vec2 uv) {
    float d = 1.0;
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            vec2 p = uv + vec2(float(x), float(y)) / 256.0;
            if (chaosTex(p).a >= 0.1) {
                vec2 v = fract(p * 256.0);
                if (x == 0) v.x = 0.0;
                if (y == 0) v.y = 0.0;
                if (x > 0) v.x = 1.0 - v.x;
                if (y > 0) v.y = 1.0 - v.y;
                d = min(d, length(v));
            }
        }
    }
    return d;
}

vec4 chaosEffekt() {
    int id = chaosInfo.x;
    float n = float(chaosInfo.y);
    bool schatten = chaosInfo.z == 2;
    float t = GameTime * 1200.0;
    int fx = chaosFx(id);
    vec3 c1;
    vec3 c2;
    vec3 c3;
    chaosFarben(id, c1, c2, c3);

    chaosUvMin = vec2(chaosRandA.x / max(chaosRandA.y, 1e-6), chaosRandA.z / max(chaosRandA.w, 1e-6));
    chaosUvMax = vec2(chaosRandB.x / max(chaosRandB.y, 1e-6), chaosRandB.z / max(chaosRandB.w, 1e-6));
    vec2 uv = texCoord0;
    if (chaosInfo.w == 1) {
        vec2 pMin = vec2(chaosOrt.x / max(chaosRandA.y, 1e-6), chaosOrt.y / max(chaosRandA.w, 1e-6));
        vec2 pMax = vec2(chaosOrt.z / max(chaosRandB.y, 1e-6), chaosOrt.w / max(chaosRandB.w, 1e-6));
        uv = chaosUvMin + (chaosPos - pMin) / (pMax - pMin) * (chaosUvMax - chaosUvMin);
    }
    vec2 groesse = chaosUvMax - chaosUvMin;
    vec2 mitte = 0.5 * (chaosUvMin + chaosUvMax);

    if ((fx & CHAOS_FX_DREHEN) != 0) {
        float p = mod((n * 2.4 - t * 15.0) / 6.2832, 6.1115);
        float w = 6.2832 * min(p, 1.0);
        float k = cos(w);
        if (abs(k) < 0.01)
            k = 0.01;
        uv.x = mitte.x + (uv.x - mitte.x) / k;
        uv.y = mitte.y + (uv.y - mitte.y) / (1.0 + 0.1 * sin(w));
    }
    vec2 lokal = (uv - chaosUvMin) / groesse;
    float zeile = floor((uv.y - chaosUvMin.y) * 256.0);
    float dunkel = schatten ? 0.25 : 1.0;

    vec4 farbe = vec4(schatten ? c3 : c1, chaosLicht.a);
    vec4 hinten = vec4(0.0);

    if ((fx & CHAOS_FX_VERLAUF) != 0)
        farbe.rgb = mix(c1, c2, clamp(lokal.y, 0.0, 1.0)) * dunkel;
    if ((fx & CHAOS_FX_REGENBOGEN) != 0)
        farbe.rgb = chaosHsv(vec3(n / 16.0 + (lokal.x * groesse.x + lokal.y * groesse.y) * 256.0 / 96.0 - t * 0.25, 0.8, 1.0)) * dunkel;
    if ((fx & CHAOS_FX_METALL) != 0)
        farbe.rgb = clamp(zeile > 3.0 ? c1 * 0.7 : (zeile == 3.0 ? c1 + 0.25 : c1), 0.0, 1.0) * dunkel;
    if ((fx & CHAOS_FX_UEBERGANG) != 0)
        farbe.rgb = mix(c1, c2, sin(t * 3.1416) * 0.5 + 0.5) * dunkel;
    if (!schatten) {
        if ((fx & CHAOS_FX_SCHIMMER) != 0 && mod(lokal.x + lokal.y - t * 5.333, 5.0) < 0.75)
            farbe.rgb = mix(farbe.rgb, vec3(1.0), 0.5);
        if ((fx & CHAOS_FX_UMRISS) != 0 && chaosNachbar(uv, 1.0))
            hinten = vec4(c2, 1.0);
        if ((fx & CHAOS_FX_FEINUMRISS) != 0 && chaosNachbar(uv, 0.5))
            hinten = vec4(c2, 1.0);
        if ((fx & CHAOS_FX_LEUCHTEN) != 0) {
            float d = 1.0 - chaosAbstand(uv);
            hinten = vec4(c2, d * d);
        }
        if ((fx & CHAOS_FX_FEUER) != 0 && chaosTex(uv + vec2(0.0, 1.0 / 256.0)).a > 0.1) {
            float h = fract(uv.y * 256.0);
            float f = chaosRausch2(lokal * 32.0 + vec2(0.0, t * 5.333)) * 0.5 + 0.5 - (1.0 - sqrt(h)) * 0.8;
            if (f > 0.5)
                hinten = vec4(mix(vec3(1.0, 0.2, 0.2), vec3(1.0, 0.7, 0.3), (f - 0.5) / 0.5), 1.0);
        }
        if ((fx & CHAOS_FX_GLITCH) != 0) {
            vec2 r = vec2(chaosRausch(t * 10.0), chaosRausch(t * 10.0 + 19732.134)) - 0.5;
            vec2 o = (vec2(0.5, 0.0) + vec2(0.5, 1.0) * r) / 256.0;
            vec4 s1 = chaosTex(uv + o);
            s1.rgb *= s1.a;
            vec4 s2 = chaosTex(uv - o);
            s2.rgb *= s2.a;
            hinten = s1 * vec4(1.0, 0.25, 0.0, 1.0) + s2 * vec4(0.0, 0.75, 1.0, 1.0);
            hinten.rgb *= farbe.rgb;
        }
    } else if ((fx & CHAOS_FX_OHNE_SCHATTEN) != 0) {
        farbe.a = 0.0;
    }
    if ((fx & CHAOS_FX_BLINKEN) != 0 && sin(t * 8.3776) < 0.0) {
        farbe.a = 0.0;
        hinten.a = 0.0;
    }

    vec4 tex = chaosTex(uv);
    vec4 aus = mix(vec4(hinten.rgb, hinten.a * farbe.a), tex * farbe, tex.a);
    aus.rgb *= chaosLicht.rgb;
    return aus;
}

void main() {
#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif

#ifdef IS_SEE_THROUGH
    vec4 color = texColor * vertexColor;
#else
    vec4 color = texColor * vertexColor * ColorModulator;
#endif
    if (chaosInfo.x > 0) {
#ifdef IS_SEE_THROUGH
        color = chaosEffekt();
#else
        color = chaosEffekt() * ColorModulator;
#endif
    }
    if (color.a < 0.1) {
        discard;
    }

    if (chaosGlanzAn > 0.5) {
        color.rgb = chaosGlanz(color.rgb, chaosLokal);
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}
