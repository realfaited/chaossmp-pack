#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;
out float chaosGlanzAn;
out vec2 chaosLokal;
flat out ivec4 chaosInfo;
out vec4 chaosRandA;
out vec4 chaosRandB;
out vec4 chaosOrt;
out vec2 chaosPos;
out vec4 chaosLicht;

// ===== ChaosSMP Text-Effekte (resourcepack/textglanz_pack.py, Vorlage Spheya „Very Cool Text Effects") =====
float chaosZufall(float s) {
    return fract(sin(s) * 43758.5453);
}

float chaosZufall2(vec2 s) {
    return fract(sin(dot(s, vec2(12.9898, 78.233))) * 43758.5453);
}

float chaosRausch(float n) {
    float i = floor(n);
    return mix(chaosZufall(i), chaosZufall(i + 1.0), smoothstep(0.0, 1.0, fract(n)));
}

float chaosRausch2(vec2 p) {
    vec2 ip = floor(p);
    vec2 u = fract(p);
    u = u * u * (3.0 - 2.0 * u);
    float r = mix(mix(chaosZufall2(ip), chaosZufall2(ip + vec2(1.0, 0.0)), u.x),
                  mix(chaosZufall2(ip + vec2(0.0, 1.0)), chaosZufall2(ip + vec2(1.0, 1.0)), u.x), u.y);
    return r * r;
}

vec3 chaosHsv(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

// Effekt-Tabelle (generiert aus resourcepack/textglanz_pack.py EFFEKTE)
const int CHAOS_FX_WACKELN = 1;
const int CHAOS_FX_WELLE = 2;
const int CHAOS_FX_HUEPFEN = 4;
const int CHAOS_FX_DREHEN = 8;
const int CHAOS_FX_KIPPEN = 16;
const int CHAOS_FX_PULSIEREN = 32;
const int CHAOS_FX_VERLAUF = 64;
const int CHAOS_FX_REGENBOGEN = 128;
const int CHAOS_FX_METALL = 256;
const int CHAOS_FX_UEBERGANG = 512;
const int CHAOS_FX_SCHIMMER = 1024;
const int CHAOS_FX_BLINKEN = 2048;
const int CHAOS_FX_UMRISS = 4096;
const int CHAOS_FX_FEINUMRISS = 8192;
const int CHAOS_FX_LEUCHTEN = 16384;
const int CHAOS_FX_FEUER = 32768;
const int CHAOS_FX_GLITCH = 65536;
const int CHAOS_FX_OHNE_SCHATTEN = 131072;
const int CHAOS_FX_RAND = 126976;
const float CHAOS_RAND = 2.0;
int chaosEffektId(int k) {
    switch (k) {
        case 4980: return 4; // DREHEN Text
        case 4981: return 16; // LEUCHTEN Text
        case 6036: return 3; // HUEPFEN Text
        case 6037: return 10; // SCHIMMER Text
        case 6038: return 14; // BLINKEN Text
        case 7548: return 5; // KIPPEN Text
        case 10928: return 12; // METALL Text
        case 15428: return 13; // FEUER Text
        case 15700: return 1; // WACKELN Text
        case 15701: return 7; // UMRISS Text
        case 15740: return 9; // REGENBOGEN Text
        case 15948: return 6; // PULSIEREN Text
        case 16268: return 2; // WELLE Text
        case 16269: return 15; // UEBERGANG Text
        case 16284: return 8; // VERLAUF Text
        case 16380: return 11; // GLITCH Text
        case 16381: return 17; // FEINUMRISS Text
        case 17748: return 3; // HUEPFEN Schatten
        case 17749: return 10; // SCHIMMER Schatten
        case 17750: return 14; // BLINKEN Schatten
        case 18592: return 5; // KIPPEN Schatten
        case 18724: return 4; // DREHEN Schatten
        case 18725: return 16; // LEUCHTEN Schatten
        case 20752: return 11; // GLITCH Schatten
        case 20753: return 17; // FEINUMRISS Schatten
        case 20756: return 12; // METALL Schatten
        case 21588: return 9; // REGENBOGEN Schatten
        case 22528: return 13; // FEUER Schatten
        case 22612: return 1; // WACKELN Schatten
        case 22613: return 7; // UMRISS Schatten
        case 22660: return 8; // VERLAUF Schatten
        case 22724: return 6; // PULSIEREN Schatten
        case 25796: return 2; // WELLE Schatten
        case 25797: return 15; // UEBERGANG Schatten
        default: return 0;
    }
}
int chaosFx(int id) {
    switch (id) {
        case 1: return 1; // WACKELN
        case 2: return 2; // WELLE
        case 3: return 4; // HUEPFEN
        case 4: return 8; // DREHEN
        case 5: return 16; // KIPPEN
        case 6: return 32; // PULSIEREN
        case 7: return 4096; // UMRISS
        case 8: return 64; // VERLAUF
        case 9: return 128; // REGENBOGEN
        case 10: return 1024; // SCHIMMER
        case 11: return 196608; // GLITCH
        case 12: return 256; // METALL
        case 13: return 32768; // FEUER
        case 14: return 2048; // BLINKEN
        case 15: return 512; // UEBERGANG
        case 16: return 147456; // LEUCHTEN
        case 17: return 8192; // FEINUMRISS
        default: return 0;
    }
}
void chaosFarben(int id, out vec3 c1, out vec3 c2, out vec3 c3) {
    c1 = vec3(1.0);
    c2 = vec3(1.0);
    c3 = vec3(0.25);
    switch (id) {
        case 1: c1 = vec3(1.0000, 0.3216, 0.3216); c2 = vec3(1.0000, 0.3216, 0.3216); c3 = vec3(0.3922, 0.0784, 0.3137); break; // WACKELN
        case 2: c1 = vec3(1.0000, 0.9216, 0.2353); c2 = vec3(1.0000, 0.9216, 0.2353); c3 = vec3(0.5882, 0.2353, 0.1176); break; // WELLE
        case 3: c1 = vec3(0.3373, 0.9216, 0.3373); c2 = vec3(0.3373, 0.9216, 0.3373); c3 = vec3(0.0784, 0.3137, 0.3529); break; // HUEPFEN
        case 4: c1 = vec3(0.2902, 0.8706, 0.8196); c2 = vec3(0.2902, 0.8706, 0.8196); c3 = vec3(0.1451, 0.2784, 0.5882); break; // DREHEN
        case 5: c1 = vec3(0.4784, 0.3137, 0.9843); c2 = vec3(0.4784, 0.3137, 0.9843); c3 = vec3(0.1569, 0.1569, 0.5490); break; // KIPPEN
        case 6: c1 = vec3(1.0000, 0.5882, 0.2353); c2 = vec3(1.0000, 0.5882, 0.2353); c3 = vec3(0.4314, 0.1961, 0.0784); break; // PULSIEREN
        case 7: c1 = vec3(1.0000, 0.3216, 0.3216); c2 = vec3(0.3922, 0.0784, 0.3137); c3 = vec3(0.3922, 0.0784, 0.3137); break; // UMRISS
        case 8: c1 = vec3(1.0000, 0.9216, 0.4706); c2 = vec3(1.0000, 0.3216, 0.3216); c3 = vec3(0.3922, 0.1569, 0.1176); break; // VERLAUF
        case 9: c1 = vec3(1.0000, 0.3333, 1.0000); c2 = vec3(1.0000, 0.3333, 1.0000); c3 = vec3(0.3137, 0.0784, 0.3137); break; // REGENBOGEN
        case 10: c1 = vec3(0.3373, 0.9216, 0.3373); c2 = vec3(0.3373, 0.9216, 0.3373); c3 = vec3(0.0784, 0.3137, 0.3529); break; // SCHIMMER
        case 11: c1 = vec3(1.0000, 1.0000, 1.0000); c2 = vec3(1.0000, 1.0000, 1.0000); c3 = vec3(0.2745, 0.2745, 0.2745); break; // GLITCH
        case 12: c1 = vec3(0.6275, 0.6275, 0.7843); c2 = vec3(0.6275, 0.6275, 0.7843); c3 = vec3(0.2510, 0.2510, 0.3529); break; // METALL
        case 13: c1 = vec3(1.0000, 0.0784, 0.0784); c2 = vec3(1.0000, 0.0784, 0.0784); c3 = vec3(0.3922, 0.0392, 0.0392); break; // FEUER
        case 14: c1 = vec3(0.3373, 0.9216, 0.3373); c2 = vec3(0.3373, 0.9216, 0.3373); c3 = vec3(0.0784, 0.3137, 0.3529); break; // BLINKEN
        case 15: c1 = vec3(1.0000, 0.9216, 0.2353); c2 = vec3(0.3373, 0.9216, 0.3373); c3 = vec3(0.5882, 0.2353, 0.1176); break; // UEBERGANG
        case 16: c1 = vec3(0.2902, 0.8706, 0.8196); c2 = vec3(1.0000, 1.0000, 1.0000); c3 = vec3(0.1451, 0.2784, 0.5882); break; // LEUCHTEN
        case 17: c1 = vec3(1.0000, 1.0000, 1.0000); c2 = vec3(1.0000, 0.6667, 0.0000); c3 = vec3(0.2745, 0.2745, 0.2745); break; // FEINUMRISS
        default: break;
    }
}

vec2 chaosBewegung(int fx, float n, float t, vec2 richtung) {
    vec2 o = vec2(0.0);
    if ((fx & CHAOS_FX_WACKELN) != 0)
        o += vec2(chaosRausch(n * 7.13 + t * 26.7), chaosRausch(n * 3.71 - t * 26.7 + 91.0)) - 0.5;
    if ((fx & CHAOS_FX_WELLE) != 0)
        o.y += sin(n * 0.7854 - t * 6.25);
    if ((fx & CHAOS_FX_HUEPFEN) != 0) {
        float x = mod(t * 15.0 - n * 2.4, 38.4);
        if (x < 6.2832)
            o.y -= (0.5 - 0.5 * cos(x)) * 1.5;
    }
    if ((fx & CHAOS_FX_KIPPEN) != 0 && richtung.y < 0.0)
        o += vec2(sin(t * 4.1888), -(0.5 + 0.5 * cos(t * 8.3776)));
    if ((fx & CHAOS_FX_PULSIEREN) != 0)
        o += richtung * vec2(0.8, 1.2) * (0.5 + 0.5 * sin(t * 10.667));
    return o;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;

    // Rang-Glanz: R/B-Muster in den unteren 4 Bit, G = Buchstaben-Nummer
    ivec3 c = ivec3(round(Color.rgb * 255.0));
    chaosGlanzAn = ((c.r & 15) == 11 && (c.b & 15) == 13) ? 1.0 : 0.0;
    int ecke = gl_VertexID % 4;
    chaosLokal = vec2(float(c.g & 15) + ((ecke == 2 || ecke == 3) ? 1.0 : 0.0), (ecke == 1 || ecke == 2) ? 1.0 : 0.0);

    // Text-Effekte: Marker in den unteren 2 Bit (Text 1/2/0, Schatten 0/3/2), Vertrag in resourcepack/textglanz_pack.py
    chaosInfo = ivec4(0);
    chaosRandA = vec4(0.0);
    chaosRandB = vec4(0.0);
    chaosOrt = vec4(0.0);
    chaosPos = vec2(0.0);
    chaosLicht = vec4(1.0);
    {
        ivec3 cc = ivec3(round(Color.rgb * 255.0));
        int art = 0;
        if ((cc.r & 3) == 1 && (cc.g & 3) == 2 && (cc.b & 3) == 0)
            art = 1;
        else if ((cc.r & 3) == 0 && (cc.g & 3) == 3 && (cc.b & 3) == 2)
            art = 2;
        int id = 0;
        if (art > 0)
            id = chaosEffektId(((art - 1) << 14) | ((cc.r >> 4) << 10) | ((cc.g >> 4) << 6) | ((cc.b >> 4) << 2) | ((cc.g >> 2) & 3));
        if (id > 0) {
            int nr = (((cc.r >> 2) & 3) << 2) | ((cc.b >> 2) & 3);
            int fx = chaosFx(id);
            // Atlas-Kante aus der UV (Nudge 0.01 Texel): 0 = links/oben, 1 = rechts/unten — unabhaengig von der Eckenreihenfolge
            vec2 seite = step(vec2(0.5), fract(UV0 * 256.0));
            vec2 richtung = seite * 2.0 - 1.0;
            vec3 pos = Position;
            int breit = 0;
            if (ProjMat[3][3] > 0.5) {
                pos.xy += chaosBewegung(fx, float(nr), GameTime * 1200.0, richtung);
                chaosOrt = vec4(pos.xy * (1.0 - seite), pos.xy * seite);
                if (art == 1 && (fx & CHAOS_FX_RAND) != 0) {
                    pos.xy += richtung * CHAOS_RAND;
                    breit = 1;
                }
                gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
            }
            chaosPos = pos.xy;
            chaosRandA = vec4(UV0.x * (1.0 - seite.x), 1.0 - seite.x, UV0.y * (1.0 - seite.y), 1.0 - seite.y);
            chaosRandB = vec4(UV0.x * seite.x, seite.x, UV0.y * seite.y, seite.y);
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
            chaosLicht = vec4(sample_lightmap(Sampler2, UV2).rgb, Color.a);
#else
            chaosLicht = vec4(1.0, 1.0, 1.0, Color.a);
#endif
            chaosInfo = ivec4(id, nr, art, breit);
        }
    }
}
