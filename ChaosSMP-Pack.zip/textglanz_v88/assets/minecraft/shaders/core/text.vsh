#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;
out float chaosGlanzAn;
out vec2 chaosLokal;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;

    // Rang-Glanz: R/B-Muster in den unteren 4 Bit, G = Buchstaben-Nummer
    ivec3 c = ivec3(round(Color.rgb * 255.0));
    chaosGlanzAn = ((c.r & 15) == 11 && (c.b & 15) == 13) ? 1.0 : 0.0;
    int ecke = gl_VertexID % 4;
    chaosLokal = vec2(float(c.g & 15) + ((ecke == 2 || ecke == 3) ? 1.0 : 0.0), (ecke == 1 || ecke == 2) ? 1.0 : 0.0);
}
