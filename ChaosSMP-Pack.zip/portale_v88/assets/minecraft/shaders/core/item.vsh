#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler1;
uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec4 lightMapColor;
out vec4 overlayColor;

out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);

    texCoord0 = UV0;

    // ChaosSMP Portal-Deckel (portale_pack.py _deckel): Stempel R 201, G 0x60|Art, B 0x8C|Ecke, A 255 -> Quad direkt vor
    // die Kamera, aber nur, wenn die Kamera hinter der Flaeche des Deckels steht (Position = Deckel - Kamera)
    ivec2 chaosDg = textureSize(Sampler0, 0);
    if (chaosDg.x >= 256 && chaosDg.y >= 256) {
        ivec4 chaosD = ivec4(round(texelFetch(Sampler0, clamp(ivec2(floor(UV0 * vec2(chaosDg))), ivec2(0), chaosDg - 1), 0) * 255.0));
        if (chaosD.r == 201 && chaosD.a == 255 && (chaosD.g & 0xF8) == 0x60 && (chaosD.b & 0xFC) == 0x8C) {
            int art = chaosD.g & 7;
            bool hinter = art == 0 ? Position.y > 0.0 : (art == 1 ? Position.x > 0.0 : (art == 2 ? Position.x < 0.0
                    : (art == 3 ? Position.z > 0.0 : Position.z < 0.0)));
            vec2 ecke = vec2(float(chaosD.b & 1), float((chaosD.b >> 1) & 1)) * 2.0 - 1.0;
            // 0,15 vor der Kamera, viermal so gross wie das Sichtfeld: Ansichtswippen beim Laufen verschiebt die Projektion
            // (Clientshot 21.10.: mit 1,3facher Groesse rutschte das Quad beim Laufen aus dem Bild, Wolken kamen durch)
            // ModelViewMat = Einheit: Client rechnet die Drehung schon in Position (Lunar-Fall 26.10.2026) -> Position ist
            // nicht in Weltachsen, "hinter" waere geraten: Deckel weg statt eines Vollbild-Quads zur falschen Zeit
            mat3 chaosMv = mat3(ModelViewMat) - mat3(1.0);
            bool chaosEinheit = dot(chaosMv[0], chaosMv[0]) + dot(chaosMv[1], chaosMv[1]) + dot(chaosMv[2], chaosMv[2]) < 1.0e-10;
            gl_Position = hinter && !chaosEinheit ? ProjMat * vec4(ecke.x * 0.6 / ProjMat[0][0], ecke.y * 0.6 / ProjMat[1][1], -0.15, 1.0)
                    : vec4(-3.0, -3.0, 0.0, 1.0);
        }
    }
    // ChaosSMP Portal-Fallbild (portale_pack.py): Stempel in einem der vier Eckpixel -> Modell aus dem Bild legen.
    // Nur Shaderpacks (die item.vsh ersetzen) zeigen das Standbild; hier sieht man das Voxel-Portal.
    ivec2 chaosGr = textureSize(Sampler0, 0);
    if (chaosGr.x >= 256 && chaosGr.y >= 256) {
        ivec2 chaosAt = ivec2(floor(UV0 * vec2(chaosGr) + 0.5));
        for (int k = 0; k < 4; k++) {
            ivec2 q = clamp(chaosAt - ivec2(k & 1, k >> 1), ivec2(0), chaosGr - 1);
            if (ivec4(round(texelFetch(Sampler0, q, 0) * 255.0)) == ivec4(201, 102, 156, 5))
                gl_Position = vec4(-3.0, -3.0, 0.0, 1.0);
        }
    }
}
