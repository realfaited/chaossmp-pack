#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in float chaosGlanzAn;
in vec2 chaosLokal;

out vec4 fragColor;

// ChaosSMP Rang-Glanz (resourcepack/textglanz_pack.py)
vec3 chaosGlanz(vec3 basis, vec2 lokal) {
    float t = mod(GameTime * 1200.0, 5.0);
    float pos = -1.5 + t * 4.50;
    float d = lokal.x + lokal.y * 0.80 - pos;
    float haupt = exp(-(d * d) / (0.55 * 0.55));
    float nach = 0.5 * exp(-((d + 0.9) * (d + 0.9)) / (0.16 * 0.16));
    float k = clamp(haupt + nach, 0.0, 1.0);
    vec3 metall = clamp(basis * (1.10 - 0.20 * lokal.y), 0.0, 1.0);
    return mix(metall, vec3(1.0), k * 0.85);
}

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }

    if (chaosGlanzAn > 0.5) {
        color.rgb = chaosGlanz(color.rgb, chaosLokal);
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
