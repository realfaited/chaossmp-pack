#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in float chaosGlanzAn;
in float chaosOben;

out vec4 fragColor;

// ChaosSMP Rang-Glanz (resourcepack/textglanz_pack.py)
vec3 chaosGlanz(vec3 basis, float oben) {
    float sek = GameTime * 1200.0;
    // 4 s je Durchlauf; 1200 / 4 ganzzahlig -> kein Sprung beim 20-min-Umbruch von GameTime
    float phase = fract(sek / 4.0);
    float h = max(ScreenSize.y, 1.0);
    // schraeg (/), in Bildschirmhoehen gemessen -> gleiche Optik bei jeder Aufloesung
    float u = (gl_FragCoord.x - gl_FragCoord.y * 0.45) / h;
    float x = fract(u * 0.8 - phase) - 0.5;
    float haupt = exp(-(x * x) / (0.022 * 0.022));
    float nach = 0.55 * exp(-((x + 0.05) * (x + 0.05)) / (0.009 * 0.009));
    float k = clamp(haupt + nach, 0.0, 1.0);
    vec3 metall = clamp(basis * (1.10 - 0.20 * (1.0 - oben)), 0.0, 1.0);
    return mix(metall, vec3(1.0), k * 0.9);
}

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }

    if (chaosGlanzAn > 0.5) {
        color.rgb = chaosGlanz(color.rgb, chaosOben);
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
