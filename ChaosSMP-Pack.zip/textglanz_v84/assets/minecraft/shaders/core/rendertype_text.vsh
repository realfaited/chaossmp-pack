#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out float chaosGlanzAn;
out float chaosOben;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;

    // Rang-Glanz: Muster in den unteren 4 Bit der Textfarbe (R=11, G=5, B=13)
    ivec3 c = ivec3(round(Color.rgb * 255.0));
    chaosGlanzAn = ((c.r & 15) == 11 && (c.g & 15) == 5 && (c.b & 15) == 13) ? 1.0 : 0.0;
    // Glyphen-Ecken: 0 oben links, 1 unten links, 2 unten rechts, 3 oben rechts
    int ecke = gl_VertexID % 4;
    chaosOben = (ecke == 0 || ecke == 3) ? 1.0 : 0.0;
}
